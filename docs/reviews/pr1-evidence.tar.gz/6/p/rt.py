import resource, subprocess, sys
p = subprocess.run(sys.argv[1:])
r = resource.getrusage(resource.RUSAGE_CHILDREN)
print(f"rss={r.ru_maxrss}KB user={r.ru_utime:.3f}s sys={r.ru_stime:.3f}s")
