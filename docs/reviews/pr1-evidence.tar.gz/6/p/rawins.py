import socket, struct
def cstr(s): return s + b'\0'
def bstr(k, v): return b'\x02' + cstr(k) + struct.pack('<i', len(v)+1) + v + b'\0'
def bint(k, v): return b'\x10' + cstr(k) + struct.pack('<i', v)
def bdoc(t, k, body): return t + cstr(k) + body
def doc(*els):
    b = b''.join(els); return struct.pack('<i', len(b)+5) + b + b'\0'
docs = []
for i in range(10):
    s = b'bad \xff\xfe utf8' if i == 5 else b'ok'
    docs.append(bdoc(b'\x03', str(i).encode(), doc(bint(b'_id', i), bstr(b's', s))))
cmd = doc(bstr(b'insert', b'u8'), bdoc(b'\x04', b'documents', doc(*docs)), bstr(b'$db', b'v6raw'))
msg = struct.pack('<iiii', 16+4+1+len(cmd), 1, 0, 2013) + struct.pack('<i', 0) + b'\x00' + cmd
s = socket.create_connection(('127.0.0.1', 36530)); s.sendall(msg)
hdr = s.recv(16); n = struct.unpack('<i', hdr[:4])[0]; body = b''
while len(body) < n-16: body += s.recv(n-16-len(body))
print(body[5:])
