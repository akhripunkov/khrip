import threading, time, urllib.request
done = []; lock = threading.Lock()
def go(i):
    r = urllib.request.urlopen(f"http://127.0.0.1:36550/q/{i}", timeout=60).read().decode()
    with lock: done.append(i)
ts = []
t0 = time.time()
for i in range(20):
    t = threading.Thread(target=go, args=(i,)); t.start(); ts.append(t); time.sleep(0.01)
for t in ts: t.join()
print("completion order:", done, "wall %.2fs" % (time.time()-t0))
