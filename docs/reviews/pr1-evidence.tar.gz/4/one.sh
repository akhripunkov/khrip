#!/usr/bin/env bash
# usage: one.sh <worktree> <script> — source one test script like tests/run.sh does
cd "$1"
export HTTP_PORT=34181 CORO_PORT=34183 TLS_PORT=34190 PG_PORT=34290 W_METEO=34601 W_HOOK=34602 W_APP=34603 W_TICK=34604 EVAL_PORT=34080 EVAL_DB_PREFIX=ev4_ CLICKHOUSE_MOCK_PORT=34371
KHC=build/khc
tmp=$(mktemp -d -p /tmp/claude-0/-home-user-khrip/c69287a0-5c25-565c-bc10-daebb195400d/scratchpad/pr1/4)
trap 'rm -rf "$tmp"' EXIT
pass=0; fail=0
failed() { echo "FAIL $1: $2"; fail=$((fail + 1)); }
source "$2"
echo "pass=$pass fail=$fail"
