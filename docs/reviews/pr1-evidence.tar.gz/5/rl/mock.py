# Ratelimit mock with injectable bugs: MODE=ok|reset10|retry0|race|nopong|timefmt
import json, math, os, sys, threading, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
W = float(os.environ.get("WINDOW_SECONDS", "2")); MODE = os.environ.get("MODE", "ok")
lock = threading.Lock(); win = {}
class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def send(self, code, body, hdr=None):
        data = json.dumps(body).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(data)))
        for k, v in (hdr or {}).items(): self.send_header(k, v)
        self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        now = time.time(); p = self.path
        if p.startswith("/limits/"):
            k = p[8:]; s, u = win.get(k, (0, 0))
            if now - s >= W: s, u = 0, 0
            reset = 0 if u == 0 else math.ceil(s + W - now)
            if MODE == "reset10" and u: reset = 10 + reset
            return self.send(200, {"key": k, "used": u, "remaining": 5 - u, "reset_in": reset})
        k = self.headers.get("X-API-Key")
        if not k: return self.send(401, {"error": "no key"})
        if MODE == "race":
            s, u = win.get(k, (now, 0)); time.sleep(0.01)
        with lock if MODE != "race" else threading.Lock():
            s, u = win.get(k, (now, 0))
            if now - s >= W: s, u = now, 0
            if MODE == "race": time.sleep(0.02)
            if u >= 5:
                ra = max(1, math.ceil(s + W - now)); ra = 0 if MODE == "retry0" else ra
                return self.send(429, {"error": "limit"}, {"Retry-After": str(ra)})
            win[k] = (s, u + 1)
        if p == "/api/ping": return self.send(200, {"pong": MODE != "nopong", "remaining": 5 - (u + 1)})
        t = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()) if MODE != "timefmt" else time.strftime("%Y/%m/%d %H:%M:%S")
        return self.send(200, {"time": t})
ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
