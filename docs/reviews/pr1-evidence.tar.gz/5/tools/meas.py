#!/usr/bin/env python3
# usage: meas.py N cmd... ; prints min wall, min cpu(user+sys), max rss KB
import os, sys, time, resource, subprocess
n=int(sys.argv[1]); cmd=sys.argv[2:]
walls=[];cpus=[];rss=[]
for i in range(n):
    t=time.perf_counter()
    pid=os.fork()
    if pid==0:
        fd=os.open('/dev/null',os.O_WRONLY); os.dup2(fd,1)
        os.execvp(cmd[0],cmd)
    _,st,ru=os.wait4(pid,0)
    walls.append(time.perf_counter()-t); cpus.append(ru.ru_utime+ru.ru_stime); rss.append(ru.ru_maxrss)
    if st!=0: print("exit",st,file=sys.stderr)
walls.sort();cpus.sort()
print(f"wall_min={walls[0]*1000:.2f}ms wall_med={walls[len(walls)//2]*1000:.2f}ms cpu_min={cpus[0]*1000:.1f}ms cpu_med={cpus[len(cpus)//2]*1000:.1f}ms maxrss={max(rss)}KB")
