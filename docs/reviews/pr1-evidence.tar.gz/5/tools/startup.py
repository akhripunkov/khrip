#!/usr/bin/env python3
# startup.py BIN PORT N [THREADS] -> min time to first HTTP response, idle RSS (KB) of process
import os, sys, time, socket, subprocess
b, port, n = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
thr = sys.argv[4] if len(sys.argv) > 4 else None
ts=[]; rss=[]
for i in range(n):
    env=dict(os.environ, PORT=str(port))
    if thr: env['THREADS']=thr
    t=time.perf_counter()
    p=subprocess.Popen([b], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    while True:
        try:
            s=socket.create_connection(('127.0.0.1',port),timeout=1)
            s.sendall(b"GET /nonexistent HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n")
            d=s.recv(100); s.close()
            if d: break
        except OSError: pass
        time.sleep(0.0005)
    ts.append(time.perf_counter()-t)
    time.sleep(0.3)
    with open(f'/proc/{p.pid}/status') as f:
        for l in f:
            if l.startswith('VmRSS'): rss.append(int(l.split()[1]))
    p.terminate(); p.wait()
ts.sort()
print(f"first_resp_min={ts[0]*1000:.2f}ms med={ts[len(ts)//2]*1000:.2f}ms idle_rss_KB={sorted(rss)}")
