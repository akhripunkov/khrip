package main

import (
	"context"
	"fmt"
	"os"
	"strconv"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

type Doc struct {
	ID     int64    `bson:"_id"`
	Name   string   `bson:"name"`
	N      int64    `bson:"n"`
	Score  float64  `bson:"score"`
	Active bool     `bson:"active"`
	Tags   []string `bson:"tags"`
}

func main() {
	ctx := context.Background()
	n, _ := strconv.Atoi(os.Getenv("N"))
	if n == 0 {
		n = 10000
	}
	cl, err := mongo.Connect(options.Client().ApplyURI(os.Getenv("MONGODB_URI")))
	if err != nil {
		panic(err)
	}
	coll := cl.Database("khrip_probe").Collection(fmt.Sprintf("g_%d", time.Now().UnixNano()))
	t0 := time.Now()
	for i := 0; i < n; i += 1000 {
		docs := make([]any, 0, 1000)
		for j := 0; j < 1000; j++ {
			k := int64(i + j)
			docs = append(docs, Doc{k, fmt.Sprintf("name-%d", k), k * 3, 1.5, k%2 == 0, []string{"a", "b"}})
		}
		if _, err := coll.InsertMany(ctx, docs); err != nil {
			panic(err)
		}
	}
	t1 := time.Now()
	cur, err := coll.Find(ctx, bson.D{}, options.Find().SetBatchSize(1000))
	if err != nil {
		panic(err)
	}
	count, sum := 0, int64(0)
	for cur.Next(ctx) {
		var d Doc
		if err := cur.Decode(&d); err != nil {
			panic(err)
		}
		count++
		sum += d.N
	}
	t2 := time.Now()
	coll.Drop(ctx)
	fmt.Fprintf(os.Stderr, "go: insert %d: %d ms; find+decode %d: %d ms; sum=%d\n", n, t1.Sub(t0).Milliseconds(), count, t2.Sub(t1).Milliseconds(), sum)
}
