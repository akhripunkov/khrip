package main

import (
	"context"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
)

type Row struct {
	ID     int64    `ch:"id"`
	Name   string   `ch:"name"`
	Score  float64  `ch:"score"`
	Active bool     `ch:"active"`
	Tags   []string `ch:"tags"`
}

func main() {
	ctx := context.Background()
	addr := strings.TrimPrefix(os.Getenv("CLICKHOUSE_URL"), "http://")
	conn, err := clickhouse.Open(&clickhouse.Options{
		Addr:     []string{addr},
		Protocol: clickhouse.HTTP,
		Auth:     clickhouse.Auth{Database: "default", Username: os.Getenv("CLICKHOUSE_USER"), Password: os.Getenv("CLICKHOUSE_PASSWORD")},
	})
	if err != nil {
		panic(err)
	}
	table := fmt.Sprintf("go_probe_%d", time.Now().UnixNano())
	if err := conn.Exec(ctx, "CREATE TABLE "+table+" (id Int64, name String, score Float64, active Bool, tags Array(String)) ENGINE = MergeTree ORDER BY id"); err != nil {
		panic(err)
	}
	t0 := time.Now()
	batch, err := conn.PrepareBatch(ctx, "INSERT INTO "+table)
	if err != nil {
		panic(err)
	}
	for k := int64(0); k < 100000; k++ {
		if err := batch.AppendStruct(&Row{k, fmt.Sprintf("name-%d", k), 1.5, k%2 == 0, []string{"a", "b"}}); err != nil {
			panic(err)
		}
	}
	if err := batch.Send(); err != nil {
		panic(err)
	}
	t1 := time.Now()
	var rows []Row
	if err := conn.Select(ctx, &rows, "SELECT id, name, score, active, tags FROM "+table); err != nil {
		panic(err)
	}
	var sum int64
	for _, r := range rows {
		sum += r.ID
	}
	t2 := time.Now()
	conn.Exec(ctx, "DROP TABLE "+table)
	fmt.Fprintf(os.Stderr, "go ch: insert 100000: %d ms; select+decode %d: %d ms; sum=%d\n", t1.Sub(t0).Milliseconds(), len(rows), t2.Sub(t1).Milliseconds(), sum)
}
