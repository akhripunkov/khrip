import concurrent.futures, json, os, sys, time, urllib.request, subprocess
port = int(os.environ.get("APORT","35555"))
env = dict(os.environ, PORT=str(port), THREADS="1")
p = subprocess.Popen([sys.argv[1]], env=env, stderr=subprocess.DEVNULL)
time.sleep(0.4)
def stat():
    with open(f"/proc/{p.pid}/stat") as f:
        parts = f.read().split(")")[-1].split()
    return (int(parts[11]) + int(parts[12])) / os.sysconf("SC_CLK_TCK")
def req(i):
    time.sleep(i * 0.005)
    t = time.time()
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/q/{i}", timeout=60) as r:
        return i, json.loads(r.read()), time.time() - t
c0 = stat(); t0 = time.time()
with concurrent.futures.ThreadPoolExecutor(30) as ex:
    res = list(ex.map(req, range(30)))
c1 = stat(); t1 = time.time()
order = sorted(res, key=lambda x: x[1]["ms"])
print("wall %.2fs server_cpu %.3fs" % (t1 - t0, c1 - c0))
print("completion order by arrival index:", [x[0] for x in order])
print("ok:", sum(1 for x in res if x[1]["ok"]), "max wait ms:", max(x[1]["ms"] for x in res))
p.terminate(); p.wait()
