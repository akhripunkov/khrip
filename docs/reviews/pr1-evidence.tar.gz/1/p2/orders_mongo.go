package main

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

type NewOrder struct {
	Customer string `json:"customer"`
	Category string `json:"category"`
	Amount   int64  `json:"amount"`
}

type Order struct {
	ID       string `json:"_id" bson:"_id"`
	Customer string `json:"customer" bson:"customer"`
	Category string `json:"category" bson:"category"`
	Amount   int64  `json:"amount" bson:"amount"`
	Status   string `json:"status" bson:"status"`
	Created  int64  `json:"created" bson:"created"`
}

type CategoryStat struct {
	ID     string `json:"_id" bson:"_id"`
	Total  int64  `json:"total" bson:"total"`
	Orders int64  `json:"orders" bson:"orders"`
}

var orders *mongo.Collection

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

func main() {
	uri := os.Getenv("MONGODB_URI")
	if uri == "" {
		uri = "mongodb://127.0.0.1:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		panic(err)
	}
	orders = client.Database("shop").Collection("orders")

	mux := http.NewServeMux()
	mux.HandleFunc("POST /orders", func(w http.ResponseWriter, r *http.Request) {
		var in NewOrder
		if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		if in.Amount <= 0 {
			http.Error(w, "amount must be positive", 400)
			return
		}
		o := Order{ID: bson.NewObjectID().Hex(), Customer: in.Customer, Category: in.Category,
			Amount: in.Amount, Status: "new", Created: time.Now().Unix()}
		if _, err := orders.InsertOne(r.Context(), o); err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		writeJSON(w, 201, o)
	})
	mux.HandleFunc("POST /orders/{id}/pay", func(w http.ResponseWriter, r *http.Request) {
		res, err := orders.UpdateOne(r.Context(),
			bson.M{"_id": r.PathValue("id"), "status": "new"},
			bson.M{"$set": bson.M{"status": "paid"}})
		if err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		if res.MatchedCount == 0 {
			http.NotFound(w, r)
			return
		}
		w.WriteHeader(204)
	})
	mux.HandleFunc("GET /stats/categories", func(w http.ResponseWriter, r *http.Request) {
		since := int64(0)
		if s := r.URL.Query().Get("since"); s != "" {
			n, err := strconv.ParseInt(s, 10, 64)
			if err != nil {
				http.Error(w, "since must be an integer", 400)
				return
			}
			since = n
		}
		pipeline := mongo.Pipeline{
			{{Key: "$match", Value: bson.M{"status": "paid", "created": bson.M{"$gte": since}}}},
			{{Key: "$group", Value: bson.M{"_id": "$category",
				"total": bson.M{"$sum": "$amount"}, "orders": bson.M{"$sum": 1}}}},
			{{Key: "$sort", Value: bson.M{"total": -1}}},
		}
		cur, err := orders.Aggregate(r.Context(), pipeline)
		if err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		out := []CategoryStat{}
		if err := cur.All(r.Context(), &out); err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		writeJSON(w, 200, out)
	})
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}
	http.ListenAndServe(":"+port, mux)
}
