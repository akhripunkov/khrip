package main

import (
	"encoding/json"
	"errors"
	"net/http"
	"os"
	"strconv"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

type NoteIn struct {
	Title string   `json:"title" bson:"title"`
	Body  string   `json:"body" bson:"body"`
	Tags  []string `json:"tags" bson:"tags"`
}

type Note struct {
	ID      string   `json:"_id" bson:"_id"`
	Title   string   `json:"title" bson:"title"`
	Body    string   `json:"body" bson:"body"`
	Tags    []string `json:"tags" bson:"tags"`
	Created int64    `json:"created" bson:"created"`
}

var notes *mongo.Collection

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

func readNote(w http.ResponseWriter, r *http.Request) (NoteIn, bool) {
	var in NoteIn
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
		http.Error(w, err.Error(), 400)
		return in, false
	}
	if in.Tags == nil {
		in.Tags = []string{}
	}
	return in, true
}

func main() {
	uri := os.Getenv("MONGODB_URI")
	if uri == "" {
		uri = "mongodb://127.0.0.1:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		panic(err)
	}
	notes = client.Database("app").Collection("notes")

	mux := http.NewServeMux()
	mux.HandleFunc("POST /notes", func(w http.ResponseWriter, r *http.Request) {
		in, ok := readNote(w, r)
		if !ok {
			return
		}
		n := Note{ID: bson.NewObjectID().Hex(), Title: in.Title, Body: in.Body, Tags: in.Tags, Created: time.Now().Unix()}
		if _, err := notes.InsertOne(r.Context(), n); err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		writeJSON(w, 201, n)
	})
	mux.HandleFunc("GET /notes/{id}", func(w http.ResponseWriter, r *http.Request) {
		var n Note
		err := notes.FindOne(r.Context(), bson.M{"_id": r.PathValue("id")}).Decode(&n)
		if errors.Is(err, mongo.ErrNoDocuments) {
			http.NotFound(w, r)
			return
		}
		if err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		writeJSON(w, 200, n)
	})
	mux.HandleFunc("GET /notes", func(w http.ResponseWriter, r *http.Request) {
		filter := bson.M{}
		if tag := r.URL.Query().Get("tag"); tag != "" {
			filter["tags"] = tag
		}
		limit := int64(20)
		if s := r.URL.Query().Get("limit"); s != "" {
			n, err := strconv.ParseInt(s, 10, 64)
			if err != nil {
				http.Error(w, "limit must be an integer", 400)
				return
			}
			limit = n
		}
		opts := options.Find().SetSort(bson.D{{Key: "created", Value: -1}}).SetLimit(limit)
		cur, err := notes.Find(r.Context(), filter, opts)
		if err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		out := []Note{}
		if err := cur.All(r.Context(), &out); err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		writeJSON(w, 200, out)
	})
	mux.HandleFunc("PUT /notes/{id}", func(w http.ResponseWriter, r *http.Request) {
		in, ok := readNote(w, r)
		if !ok {
			return
		}
		var n Note
		opts := options.FindOneAndUpdate().SetReturnDocument(options.After)
		err := notes.FindOneAndUpdate(r.Context(), bson.M{"_id": r.PathValue("id")}, bson.M{"$set": in}, opts).Decode(&n)
		if errors.Is(err, mongo.ErrNoDocuments) {
			http.NotFound(w, r)
			return
		}
		if err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		writeJSON(w, 200, n)
	})
	mux.HandleFunc("DELETE /notes/{id}", func(w http.ResponseWriter, r *http.Request) {
		res, err := notes.DeleteOne(r.Context(), bson.M{"_id": r.PathValue("id")})
		if err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		if res.DeletedCount == 0 {
			http.NotFound(w, r)
			return
		}
		w.WriteHeader(204)
	})
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}
	http.ListenAndServe(":"+port, mux)
}
