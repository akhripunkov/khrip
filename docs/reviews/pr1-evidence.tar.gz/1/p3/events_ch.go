package main

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
)

type EventIn struct {
	UserID int64   `json:"user_id"`
	Page   string  `json:"page"`
	Ms     float64 `json:"ms"`
}

type PageStat struct {
	Page  string  `json:"page" ch:"page"`
	Views uint64  `json:"views" ch:"views"`
	Users uint64  `json:"users" ch:"users"`
	AvgMs float64 `json:"avg_ms" ch:"avg_ms"`
}

var conn driver.Conn

func env(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

func intParam(r *http.Request, name string, def int64) (int64, bool) {
	s := r.URL.Query().Get(name)
	if s == "" {
		return def, def >= 0
	}
	n, err := strconv.ParseInt(s, 10, 64)
	return n, err == nil
}

func main() {
	var err error
	conn, err = clickhouse.Open(&clickhouse.Options{
		Addr: []string{env("CLICKHOUSE_ADDR", "127.0.0.1:9000")},
		Auth: clickhouse.Auth{Database: "default", Username: env("CLICKHOUSE_USER", "default"),
			Password: os.Getenv("CLICKHOUSE_PASSWORD")},
	})
	if err != nil {
		panic(err)
	}
	mux := http.NewServeMux()
	mux.HandleFunc("POST /events", func(w http.ResponseWriter, r *http.Request) {
		var in []EventIn
		if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		if len(in) == 0 || len(in) > 10000 {
			http.Error(w, "send 1..10000 events", 400)
			return
		}
		batch, err := conn.PrepareBatch(r.Context(), "INSERT INTO events (ts, user_id, page, ms)")
		if err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		ts := time.Now().Unix()
		for _, e := range in {
			if err := batch.Append(ts, e.UserID, e.Page, e.Ms); err != nil {
				http.Error(w, err.Error(), 503)
				return
			}
		}
		if err := batch.Send(); err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		writeJSON(w, 202, map[string]int{"inserted": len(in)})
	})
	mux.HandleFunc("GET /stats/pages", func(w http.ResponseWriter, r *http.Request) {
		from, ok1 := intParam(r, "from", -1)
		to, ok2 := intParam(r, "to", -1)
		limit, ok3 := intParam(r, "limit", 10)
		if !ok1 || !ok2 || !ok3 {
			http.Error(w, "from, to and limit must be integers", 400)
			return
		}
		rows := []PageStat{}
		err := conn.Select(r.Context(), &rows, `SELECT page, count() AS views, uniq(user_id) AS users, avg(ms) AS avg_ms
			FROM events WHERE ts >= ? AND ts < ?
			GROUP BY page ORDER BY views DESC LIMIT ?`, from, to, limit)
		if err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		writeJSON(w, 200, rows)
	})
	http.ListenAndServe(":"+env("PORT", "8080"), mux)
}
