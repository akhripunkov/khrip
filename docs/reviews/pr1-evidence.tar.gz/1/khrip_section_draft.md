## MongoDB and ClickHouse

```khrip
let m = Mongo { uri: env("MONGODB_URI") ?? "mongodb://127.0.0.1:27017" }
let r = mongo_insert(m, "app", "notes", [to_bson(note)])   // [Bson]
if r.error != "" { return 503 r.error }                       // r.code 11000: duplicate
let c = mongo_find(m, "app", "notes", to_bson({"tags": tag}), 100, 20) // batch, limit
var out: [Note] = []
while true {
    for d in c.documents { if let n = from_bson_note(d) { out.push(n) } }
    if !mongo_next(c) { break }
}
if c.error != "" { return 503 c.error }
let u = mongo_update(m, "app", "notes", to_bson({"_id": id}), to_bson({"$set": body}))
let gone = bson_get_int(mongo_delete(m, "app", "notes", filter).document, "n") ?? 0
let f = bson_new()                       // mixed-type documents
bson_str(f, "status", "paid")
bson_doc(f, "amount", to_bson({"$gt": 100}))
let filter = bson_finish(f)
let ch = ChConfig { url: env("CLICKHOUSE_URL") ?? "http://127.0.0.1:8123", user: "u", password: "p" }
let w = ch_insert(ch, "events", ch_encode(rows))          // columns Int64/Float64/Bool/String only
let q = ch_query_params(ch, `SELECT page, count() AS n FROM events WHERE ts >= {from:Int64} GROUP BY page`,
    {"from": from.to_str()})
if !q.ok { return 503 q.error }
let stats: [PageStat]? = ch_decode(q.body)                // none: ch_error()
```

- `to_bson(struct or map[str, T])` → `Bson`; `let x: T? = from_bson(doc)`; `T?` is
  written as null (never omitted), so `$set` with optional fields clears them.
  Do not put a `Bson` inside a map or struct passed to `to_bson`: use `bson_doc`.
- Operations return `MongoResult { document, error, code, unknown_outcome }` /
  `ChResult { ok, status, body, error, query_id, unknown_outcome }`; nothing
  fails the request by itself and nothing retries. `mongo_cursor(m, db, coll,
  command)` runs a raw `find` (sort, projection) or `aggregate` (needs `cursor: {}`).
- In ClickHouse `{x}` is Khrip interpolation, not a parameter: use backticks and
  `{name:Type}` with `ch_query_params`. No network calls inside `tx`.
