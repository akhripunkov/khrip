import http.client, json, sys, threading, time
port = int(sys.argv[1]); n = int(sys.argv[2]); ms = int(sys.argv[3]); users = sys.argv[4].split(",")
res = []; lock = threading.Lock()
def w(i):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=120)
    t = time.time(); c.request("GET", f"/p/{users[i % len(users)]}/{ms}"); r = c.getresponse(); b = r.read()
    with lock: res.append((r.status, json.loads(b) if r.status == 200 else b[:80], time.time() - t))
t = time.time()
ts = [threading.Thread(target=w, args=(i,)) for i in range(n)]
[x.start() for x in ts]; [x.join() for x in ts]
lat = sorted(r[2] for r in res)
bad = [r for r in res if r[0] != 200 or not r[1].get("ok")]
print(f"{n} x {ms}ms users={users}: wall {time.time()-t:.2f}s p50 {lat[n//2]:.2f}s max {lat[-1]:.2f}s failures {len(bad)}", bad[:3])
