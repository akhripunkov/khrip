import http.client, json, sys, threading, time, uuid
port = int(sys.argv[1]); mode = sys.argv[2]
def req(method, path, timeout=60):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=timeout)
    t = time.time(); c.request(method, path); r = c.getresponse(); body = r.read(); c.close()
    return r.status, body, time.time() - t
if mode == "rt":
    nthreads, per = int(sys.argv[3]), int(sys.argv[4])
    bad = []; lock = threading.Lock(); run = uuid.uuid4().hex[:8]
    def worker(k):
        for i in range(per):
            s, b, _ = req("POST", f"/rt/{run}-{k}-{i}")
            if s != 200 or not json.loads(b).get("ok"):
                with lock: bad.append((s, b[:200]))
    t = time.time()
    ts = [threading.Thread(target=worker, args=(k,)) for k in range(nthreads)]
    [x.start() for x in ts]; [x.join() for x in ts]
    print(f"rt: {nthreads*per} round trips in {time.time()-t:.2f}s, failures {len(bad)}", bad[:5])
elif mode == "hold":
    n, ms = int(sys.argv[3]), int(sys.argv[4])
    res = []; lock = threading.Lock()
    def w():
        s, b, d = req("GET", f"/hold/{ms}")
        with lock: res.append((s, json.loads(b).get("ok") if s == 200 else b[:100], d))
    t = time.time()
    ts = [threading.Thread(target=w) for _ in range(n)]
    [x.start() for x in ts]; [x.join() for x in ts]
    ok = sum(1 for r in res if r[1] is True)
    lat = sorted(r[2] for r in res)
    print(f"hold: {n} x {ms}ms in {time.time()-t:.2f}s ok={ok} p50={lat[len(lat)//2]:.2f}s max={lat[-1]:.2f}s", [r for r in res if r[1] is not True][:3])
elif mode == "hol":
    # head-of-line: start /bigfind and measure /ping latencies in parallel
    out = {}
    def big():
        out["big"] = req("GET", "/bigfind")
    th = threading.Thread(target=big); th.start()
    time.sleep(0.05)
    lat = []
    while th.is_alive():
        s, b, d = req("GET", "/ping"); lat.append(d); time.sleep(0.02)
    th.join()
    print(f"bigfind status={out['big'][0]} took {out['big'][2]:.2f}s; /ping during it: n={len(lat)} max={max(lat) if lat else 0:.3f}s")
