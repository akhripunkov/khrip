import socket, struct, sys
def cstr(s): return s + b"\0"
def bstr(s): return struct.pack("<i", len(s) + 1) + s + b"\0"
def doc(elems):
    body = b"".join(elems); return struct.pack("<i", len(body) + 5) + body + b"\0"
def el(k, n, p): return bytes([k]) + cstr(n) + p
def arr(docs): return doc([el(3, str(i).encode(), d) for i, d in enumerate(docs)])
def cmd(sock, body, rid=[1]):
    rid[0] += 1
    msg = struct.pack("<iiiiI", 0, rid[0], 0, 2013, 0) + b"\0" + body
    msg = struct.pack("<i", len(msg)) + msg[4:]
    sock.sendall(msg)
    hdr = sock.recv(4, socket.MSG_WAITALL); n = struct.unpack("<i", hdr)[0]
    rest = b""
    while len(rest) < n - 4: rest += sock.recv(n - 4 - len(rest))
    return rest
s = socket.create_connection(("127.0.0.1", int(sys.argv[1])))
docs = [doc([el(0x10, b"_id", struct.pack("<i", i)), el(2, b"s", bstr(b"ok"))]) for i in range(5)]
docs.append(doc([el(0x10, b"_id", struct.pack("<i", 5)), el(2, b"s", bstr(b"bad \xff\xfe utf8"))]))
docs += [doc([el(0x10, b"_id", struct.pack("<i", i)), el(2, b"s", bstr(b"ok"))]) for i in range(6, 10)]
print(cmd(s, doc([el(2, b"drop", bstr(b"bad")), el(2, b"$db", bstr(b"rv2_bson"))]))[-40:])
r = cmd(s, doc([el(2, b"insert", bstr(b"bad")), el(4, b"documents", arr(docs)), el(2, b"$db", bstr(b"rv2_bson"))]))
print(r)
