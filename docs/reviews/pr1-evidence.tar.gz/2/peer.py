#!/usr/bin/env python3
# Adversarial MongoDB peer: SCRAM-SHA-256 server with fault modes, delay probe,
# and in-flight accounting. Usage: peer.py PORT
import base64, hashlib, hmac, os, socketserver, struct, sys, threading, time

def i32(v): return struct.pack('<i', v)

def enc(fields):
    out = bytearray()
    for k, v in fields.items():
        n = k.encode() + b'\0'
        if isinstance(v, bool): out += b'\x08' + n + bytes([v])
        elif isinstance(v, int): out += b'\x10' + n + i32(v)
        elif isinstance(v, float): out += b'\x01' + n + struct.pack('<d', v)
        elif isinstance(v, bytes): out += b'\x05' + n + i32(len(v)) + b'\0' + v
        else:
            e = v.encode(); out += b'\x02' + n + i32(len(e) + 1) + e + b'\0'
    return i32(len(out) + 5) + bytes(out) + b'\0'

def dec(b):
    out = {}; p = 4; end = len(b) - 1
    while p < end:
        k = b[p]; z = b.index(0, p + 1); name = b[p + 1:z].decode(); p = z + 1
        if k == 2:
            n = struct.unpack_from('<i', b, p)[0]; out[name] = b[p + 4:p + 3 + n].decode('utf-8', 'replace'); p += 4 + n
        elif k == 16: out[name] = struct.unpack_from('<i', b, p)[0]; p += 4
        elif k == 18: out[name] = struct.unpack_from('<q', b, p)[0]; p += 8
        elif k == 1: out[name] = struct.unpack_from('<d', b, p)[0]; p += 8
        elif k == 8: out[name] = bool(b[p]); p += 1
        elif k == 5:
            n = struct.unpack_from('<i', b, p)[0]; out[name] = b[p + 5:p + 5 + n]; p += 5 + n
        elif k in (3, 4):
            n = struct.unpack_from('<i', b, p)[0]; out[name] = b[p:p + n]; p += n
        else: raise ValueError(k)
    return out

def msg(req, body):
    return i32(21 + len(body)) + i32(1) + i32(req) + i32(2013) + i32(0) + b'\0' + body

def recv_exact(s, n):
    d = bytearray()
    while len(d) < n:
        c = s.recv(n - len(d))
        if not c: return None
        d += c
    return bytes(d)

STATE = {'inflight': 0, 'max_inflight': 0, 'conns': 0, 'max_conns': 0, 'auths': 0, 'probes': 0}
LOCK = threading.Lock()
PASSWORD = 'pw'

class H(socketserver.BaseRequestHandler):
    def handle(self):
        s = self.request
        with LOCK:
            STATE['conns'] += 1; STATE['max_conns'] = max(STATE['max_conns'], STATE['conns'])
        conv = {}
        try:
            while True:
                h = recv_exact(s, 16)
                if h is None: return
                size, req, _, op = struct.unpack('<iiii', h)
                data = recv_exact(s, size - 16)
                if data is None: return
                body = data[5:]
                cmd = dec(body)
                name = next(iter(cmd))
                if name == 'hello':
                    s.sendall(msg(req, enc({'isWritablePrimary': True, 'maxWireVersion': 25, 'maxBsonObjectSize': 16777216, 'maxMessageSizeBytes': 48000000, 'maxWriteBatchSize': 100000, 'ok': 1.0})))
                elif name == 'saslStart':
                    payload = cmd['payload'].decode()
                    assert payload.startswith('n,,')
                    bare = payload[3:]
                    attrs = dict(a.split('=', 1) for a in bare.split(','))
                    user = attrs['n']; cnonce = attrs['r']
                    salt = os.urandom(52 if user == 'salt52' else 28)
                    it = {'iter1m': 1000000, 'iter1m1': 1000001}.get(user, 4096)
                    snonce = ('x' + cnonce) if user == 'badnonce' else cnonce + base64.b64encode(os.urandom(18)).decode()
                    first = f'r={snonce},s={base64.b64encode(salt).decode()},i={it}'
                    conv = {'user': user, 'bare': bare, 'first': first, 'salt': salt, 'it': it, 'snonce': snonce}
                    if user == 'skipauth':
                        s.sendall(msg(req, enc({'conversationId': 1, 'done': True, 'payload': b'', 'ok': 1.0})))
                        continue
                    s.sendall(msg(req, enc({'conversationId': 1, 'done': False, 'payload': first.encode(), 'ok': 1.0})))
                elif name == 'saslContinue':
                    p = cmd['payload'].decode()
                    if p == '':
                        s.sendall(msg(req, enc({'conversationId': 1, 'done': conv['user'] != 'nodone', 'payload': b'', 'ok': 1.0})))
                        if conv['user'] != 'nodone':
                            with LOCK: STATE['auths'] += 1
                        continue
                    final_wo = p[:p.rindex(',p=')]
                    proof = base64.b64decode(p[p.rindex(',p=') + 3:])
                    salted = hashlib.pbkdf2_hmac('sha256', PASSWORD.encode(), conv['salt'], conv['it'])
                    ck = hmac.new(salted, b'Client Key', 'sha256').digest()
                    sk = hashlib.sha256(ck).digest()
                    auth = conv['bare'] + ',' + conv['first'] + ',' + final_wo
                    sig = hmac.new(sk, auth.encode(), 'sha256').digest()
                    if bytes(a ^ b for a, b in zip(ck, sig)) != proof:
                        s.sendall(msg(req, enc({'ok': 0.0, 'errmsg': 'Authentication failed.', 'code': 18})))
                        continue
                    srv = hmac.new(hmac.new(salted, b'Server Key', 'sha256').digest(), auth.encode(), 'sha256').digest()
                    if conv['user'] == 'badproof':
                        srv = bytes(32)
                    done = conv['user'] not in ('nodone', 'twostep')
                    s.sendall(msg(req, enc({'conversationId': 1, 'done': done, 'payload': ('v=' + base64.b64encode(srv).decode()).encode(), 'ok': 1.0})))
                    if done:
                        with LOCK: STATE['auths'] += 1
                elif name == 'probe':
                    mode = cmd['probe']
                    with LOCK:
                        STATE['probes'] += 1; STATE['inflight'] += 1
                        STATE['max_inflight'] = max(STATE['max_inflight'], STATE['inflight'])
                    if mode.startswith('delay'):
                        time.sleep(int(mode[5:]) / 1000)
                    with LOCK: STATE['inflight'] -= 1
                    s.sendall(msg(req, enc({'ok': 1.0})))
                    if mode == 'closeafter':
                        return
                    if mode == 'extra':
                        time.sleep(0.05); s.sendall(b'\x00' * 8)
                elif name == 'stats':
                    with LOCK: st = dict(STATE)
                    s.sendall(msg(req, enc({**{k: int(v) for k, v in st.items()}, 'ok': 1.0})))
                elif name == 'reset':
                    with LOCK:
                        for k in STATE: STATE[k] = 0
                        STATE['conns'] = 1
                    s.sendall(msg(req, enc({'ok': 1.0})))
                else:
                    s.sendall(msg(req, enc({'ok': 0.0, 'errmsg': 'no such command ' + name, 'code': 59})))
        except (ConnectionError, OSError):
            return
        finally:
            with LOCK: STATE['conns'] -= 1

class S(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

S(('127.0.0.1', int(sys.argv[1])), H).serve_forever()
