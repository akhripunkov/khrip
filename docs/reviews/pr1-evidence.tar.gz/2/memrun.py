import resource, subprocess, sys, time
t=time.time()
r=subprocess.run(sys.argv[1:])
u=resource.getrusage(resource.RUSAGE_CHILDREN)
print(f"rc={r.returncode} wall={time.time()-t:.2f}s user={u.ru_utime:.2f} sys={u.ru_stime:.2f} maxrss={u.ru_maxrss/1024:.0f}MB", file=sys.stderr)
