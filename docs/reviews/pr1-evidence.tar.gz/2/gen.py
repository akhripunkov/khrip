#!/usr/bin/env python3
# Corpus generator for BSON / OP_MSG fuzzing of lib/bson.kh and lib/mongo.kh.
# Output: corpus file of [u32 kind][u32 len][bytes] records, and expected.txt with
# the reference validator's verdict (1/0) for each BSON record.
import random, struct, sys

def cstr(s):
    return s + b"\x00"

def bstr(s):
    return struct.pack("<i", len(s) + 1) + s + b"\x00"

def doc(elems):
    body = b"".join(elems)
    return struct.pack("<i", len(body) + 5) + body + b"\x00"

def el(kind, name, payload):
    return bytes([kind]) + cstr(name) + payload

def arr(items):
    return doc([el(k, str(i).encode(), p) for i, (k, p) in enumerate(items)])

def seed(rng):
    inner = doc([el(0x10, b"a", struct.pack("<i", -5)), el(0x02, b"s", bstr("Привет 🌍".encode()))])
    elems = [
        el(0x01, b"dbl", struct.pack("<d", 1.5)),
        el(0x02, b"str", bstr(b"hello\x00world")),
        el(0x03, b"doc", inner),
        el(0x04, b"arr", arr([(0x10, struct.pack("<i", 1)), (0x03, inner), (0x02, bstr(b"x"))])),
        el(0x05, b"bin", struct.pack("<i", 3) + b"\x80" + b"abc"),
        el(0x05, b"old", struct.pack("<i", 7) + b"\x02" + struct.pack("<i", 3) + b"xyz"),
        el(0x06, b"undef", b""),
        el(0x07, b"oid", bytes(range(12))),
        el(0x08, b"t", b"\x01"),
        el(0x09, b"date", struct.pack("<q", -1)),
        el(0x0A, b"null", b""),
        el(0x0B, b"re", cstr(b"^a.*") + cstr(b"i")),
        el(0x0C, b"dbp", bstr(b"ns") + bytes(12)),
        el(0x0D, b"js", bstr(b"function(){}")),
        el(0x0E, b"sym", bstr(b"sym")),
        el(0x0F, b"cws", (lambda c, s: struct.pack("<i", 4 + len(c) + len(s)) + c + s)(bstr(b"x"), doc([el(0x10, b"y", struct.pack("<i", 1))]))),
        el(0x10, b"i32", struct.pack("<i", -2147483648)),
        el(0x11, b"ts", struct.pack("<II", 1, 2)),
        el(0x12, b"i64", struct.pack("<q", -2**63)),
        el(0x13, b"dec", bytes(16)),
        el(0xFF, b"min", b""),
        el(0x7F, b"max", b""),
    ]
    rng.shuffle(elems)
    return doc(elems[: rng.randint(1, len(elems))])

# ---- reference validator (BSON 1.1 + MongoDB rules used by the PR) ----
def utf8_ok(b):
    try:
        b.decode("utf-8", "strict")
        return True
    except UnicodeDecodeError:
        return False

class Bad(Exception):
    pass

def u32(b, p):
    if p + 4 > len(b):
        raise Bad()
    return struct.unpack_from("<I", b, p)[0]

def cstring(b, p, end):
    z = b.find(b"\x00", p, end)
    if z < 0:
        raise Bad()
    if not utf8_ok(b[p:z]):
        raise Bad()
    return z + 1

def string(b, p, end):
    if end - p < 4:
        raise Bad()
    n = u32(b, p)
    if n < 1 or n > end - p - 4 or b[p + 4 + n - 1] != 0:
        raise Bad()
    if not utf8_ok(b[p + 4 : p + 4 + n - 1]):
        raise Bad()
    return p + 4 + n

def value(b, kind, p, end, depth):
    fixed = {1: 8, 9: 8, 17: 8, 18: 8, 16: 4, 7: 12, 19: 16}
    if kind in fixed:
        if fixed[kind] > end - p:
            raise Bad()
        return p + fixed[kind]
    if kind in (6, 10, 127, 255):
        return p
    if kind == 8:
        if p >= end or b[p] > 1:
            raise Bad()
        return p + 1
    if kind in (2, 13, 14):
        return string(b, p, end)
    if kind in (3, 4):
        if end - p < 5:
            raise Bad()
        n = u32(b, p)
        if n < 5 or n > end - p:
            raise Bad()
        document(b, p, n, depth + 1, kind == 4)
        return p + n
    if kind == 5:
        if end - p < 5:
            raise Bad()
        n = u32(b, p)
        if n > end - p - 5:
            raise Bad()
        if b[p + 4] == 2:
            if n < 4 or u32(b, p + 5) != n - 4:
                raise Bad()
        return p + 5 + n
    if kind == 11:
        q = cstring(b, p, end)
        return cstring(b, q, end)
    if kind == 12:
        q = string(b, p, end)
        if end - q < 12:
            raise Bad()
        return q + 12
    if kind == 15:
        if end - p < 4:
            raise Bad()
        n = u32(b, p)
        if n < 14 or n > end - p:
            raise Bad()
        q = string(b, p + 4, p + n)
        r = value(b, 3, q, p + n, depth)
        if r != p + n:
            raise Bad()
        return r
    raise Bad()

def document(b, p, n, depth, array):
    if depth > 64 or n < 5 or n > 16777216:
        raise Bad()
    if u32(b, p) != n or b[p + n - 1] != 0:
        raise Bad()
    end = p + n - 1
    at = p + 4
    idx = 0
    while at < end:
        kind = b[at]
        z = b.find(b"\x00", at + 1, end)
        if z < 0:
            raise Bad()
        name = b[at + 1 : z]
        if not utf8_ok(name):
            raise Bad()
        if array and name != str(idx).encode():
            raise Bad()
        at = value(b, kind, z + 1, end, depth)
        idx += 1
    if at != end:
        raise Bad()

def valid(b):
    try:
        if len(b) < 5:
            return False
        document(b, 0, len(b), 0, False)
        return True
    except (Bad, IndexError):
        return False

def mutate(rng, b):
    b = bytearray(b)
    for _ in range(rng.randint(1, 4)):
        op = rng.randint(0, 9)
        if op == 0 and b:
            b[rng.randrange(len(b))] = rng.randrange(256)
        elif op == 1 and len(b) > 4:
            p = rng.randrange(len(b) - 3)
            v = rng.choice([0, 1, 4, 5, 0x7FFFFFFF, 0x80000000, 0xFFFFFFFF, 0xFFFFFFFB, len(b), len(b) - p, len(b) - p + 1, rng.randrange(1 << 32)])
            struct.pack_into("<I", b, p, v)
        elif op == 2 and b:
            del b[rng.randrange(len(b)):]
        elif op == 3:
            p = rng.randrange(len(b) + 1)
            b[p:p] = bytes(rng.randrange(256) for _ in range(rng.randint(1, 8)))
        elif op == 4 and b:
            p = rng.randrange(len(b))
            del b[p : p + rng.randint(1, 8)]
        elif op == 5 and b:
            b[rng.randrange(len(b))] = rng.choice([0, 1, 2, 3, 4, 5, 0x7F, 0x80, 0xC0, 0xED, 0xF4, 0xF5, 0xFF])
        elif op == 6 and len(b) >= 4:
            # fix outer length after other edits to reach deeper code
            struct.pack_into("<I", b, 0, len(b))
        elif op == 7 and b:
            b[-1] = rng.choice([0, 1])
        elif op == 8 and len(b) > 8:
            # flip a type byte to a random kind, then fix outer length
            p = rng.randrange(4, len(b) - 1)
            b[p] = rng.choice([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 0, 127, 255, 128])
        else:
            if len(b) >= 4:
                struct.pack_into("<I", b, 0, len(b))
    return bytes(b)

def deep(n):
    d = doc([el(0x10, b"x", struct.pack("<i", 1))])
    for i in range(n):
        d = doc([el(0x03, b"d", d)])
    return d

def deep_arr(n):
    d = doc([])
    for i in range(n):
        d = doc([el(0x04, b"0", d)])
    return d

def opmsg(rng, body, req):
    flags = 0
    extra = b""
    r = rng.randint(0, 6)
    if r == 0:
        flags = 1
    frame = struct.pack("<iiiiI", 0, 99, req, 2013, flags) + b"\x00" + body
    if flags & 1:
        frame += b"\x00\x00\x00\x00"  # wrong checksum most of the time
    frame = bytearray(frame)
    struct.pack_into("<i", frame, 0, len(frame))
    return bytes(frame)

def main():
    out = sys.argv[1]
    exp = sys.argv[2]
    count = int(sys.argv[3])
    rng = random.Random(int(sys.argv[4]) if len(sys.argv) > 4 else 1)
    recs = []
    verdicts = []
    special = [deep(63), deep(64), deep(65), deep(200), deep_arr(64), deep_arr(65),
               doc([el(0x04, b"a", doc([el(0x10, b"1", struct.pack("<i", 1))]))]),
               doc([el(0x04, b"a", doc([el(0x10, b"00", struct.pack("<i", 1))]))]),
               doc([el(0x02, b"s", struct.pack("<i", 0) + b"\x00")]),
               doc([el(0x02, b"s", struct.pack("<I", 0xffffffff) + b"\x00")]),
               doc([el(0x05, b"b", struct.pack("<I", 0xffffffff) + b"\x00")]),
               doc([el(0x05, b"b", struct.pack("<i", 0) + b"\x02")]),
               doc([el(0x05, b"b", struct.pack("<i", 4) + b"\x02" + struct.pack("<i", 0))]),
               doc([el(0x05, b"b", struct.pack("<i", 4) + b"\x02" + struct.pack("<I", -4 & 0xffffffff))]),
               doc([el(0x0F, b"c", struct.pack("<i", 13) + bstr(b"") + doc([]))]),
               doc([el(0x0F, b"c", struct.pack("<i", 14) + bstr(b"") + doc([]))]),
               doc([el(0x02, b"\xed\xa0\x80", bstr(b"x"))]),
               doc([el(0x02, b"k", bstr(b"\xf4\x90\x80\x80"))]),
               doc([el(0x02, b"k", bstr(b"\xf0\x9f\x98"))]),
               doc([el(0x08, b"k", b"\x02")]),
               ]
    for s in special:
        recs.append((0, s))
        verdicts.append(valid(s))
    for i in range(count):
        s = seed(rng)
        m = mutate(rng, s) if rng.random() < 0.9 else s
        recs.append((0, m))
        verdicts.append(valid(m))
    # OP_MSG frames (kind 1); the expected verdict is not checked, only safety.
    for i in range(count // 4):
        s = seed(rng)
        okd = doc([el(0x01, b"ok", struct.pack("<d", 1.0))] + ([el(0x03, b"cursor", doc([el(0x12, b"id", struct.pack("<q", 0)), el(0x04, b"firstBatch", arr([(0x03, s)]))]))] if rng.random() < 0.5 else []))
        f = opmsg(rng, okd, 7)
        if rng.random() < 0.8:
            f = mutate(rng, f)
        recs.append((1, f))
    with open(out, "wb") as fh:
        for k, r in recs:
            fh.write(struct.pack("<II", k, len(r)) + r)
    with open(exp, "w") as fh:
        for v in verdicts:
            fh.write("1\n" if v else "0\n")
    print(f"{len(recs)} records, {sum(verdicts)} valid BSON")

main()
