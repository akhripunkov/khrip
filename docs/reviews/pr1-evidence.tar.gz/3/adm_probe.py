import concurrent.futures, json, os, subprocess, sys, time, urllib.request
port = int(sys.argv[1]); mock = sys.argv[2]; nreq = int(sys.argv[3]); threads = sys.argv[4]
env = dict(os.environ, PORT=str(port), THREADS=threads, MOCK=mock)
p = subprocess.Popen(["./adm"], env=env, stderr=open("adm.err","w"))
base = f"http://127.0.0.1:{port}"
for _ in range(200):
    try:
        urllib.request.urlopen(base + "/active", timeout=1).read(); break
    except OSError:
        time.sleep(0.02)
def cpu():
    with open(f"/proc/{p.pid}/stat") as f:
        parts = f.read().rsplit(")", 1)[1].split()
    return (int(parts[11]) + int(parts[12])) / os.sysconf("SC_CLK_TCK")
def get(path):
    with urllib.request.urlopen(base + path, timeout=60) as r:
        return json.loads(r.read())
c0 = cpu(); t0 = time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=nreq) as pool:
    futs = [pool.submit(get, "/q?n=1&timeout_ms=3500") for _ in range(nreq)]
    time.sleep(1.5)
    c1 = cpu(); t1 = time.time()
    res = [f.result() for f in futs]
c2 = cpu(); t2 = time.time()
ok = sum(r["ok"] for r in res); timeouts = sum((not r["ok"]) and "admission" in r["error"] for r in res)
print(f"requests={nreq} THREADS={threads} ok={ok} admission_timeouts={timeouts} other={nreq-ok-timeouts}")
print(f"server CPU during first 1.5s of queueing: {c1-c0:.2f}s cpu over {t1-t0:.2f}s wall")
print(f"server CPU total: {c2-c0:.2f}s over {t2-t0:.2f}s wall")
errs = {}
for r in res:
    k = (r["ok"], r["unknown"], r["error"][:60])
    errs[k] = errs.get(k, 0) + 1
print(errs)
print("active after:", [get("/active") for _ in range(4)])
p.terminate(); p.wait()
