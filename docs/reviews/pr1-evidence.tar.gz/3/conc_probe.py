import concurrent.futures, json, os, subprocess, sys, time, urllib.request
port = int(sys.argv[1])
env = dict(os.environ, PORT=str(port), THREADS="4", CLICKHOUSE_URL="http://127.0.0.1:8123")
subprocess.run(["curl","-s","-u","khrip:khrip-pass","http://127.0.0.1:8123/","--data-binary","DROP TABLE IF EXISTS rv3_khrip.conc_t"])
subprocess.run(["curl","-s","-u","khrip:khrip-pass","http://127.0.0.1:8123/","--data-binary","CREATE TABLE rv3_khrip.conc_t (k Int64, i Int64, s String, n Nullable(Int64), tags Array(String)) ENGINE=MergeTree ORDER BY (k,i)"])
p = subprocess.Popen(["./conc"], env=env, stderr=open("conc.err","w"))
base = f"http://127.0.0.1:{port}"
def get(path):
    with urllib.request.urlopen(base + path, timeout=60) as r:
        return json.loads(r.read())
for _ in range(200):
    try:
        get("/active"); break
    except OSError:
        time.sleep(0.02)
t0 = time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=32) as pool:
    ins = list(pool.map(lambda k: get(f"/ins/{k}"), range(200)))
    slow = list(pool.map(lambda k: get("/slow"), range(40)))
    gets = list(pool.map(lambda k: get(f"/get/{k}"), range(200)))
print("inserts ok:", sum(r["ok"] for r in ins), "/200", set(r["err"][:80] for r in ins if not r["ok"]))
print("slow: ok", sum(r["ok"] for r in slow), "unknown", sum(r["n"] for r in slow), set(r["err"][:60] for r in slow))
print("gets ok:", sum(r["ok"] for r in gets), "/200", set((r["n"], r["err"][:80]) for r in gets if not r["ok"]))
print("active samples:", sorted(set(get("/active") for _ in range(64))))
print("elapsed %.2fs" % (time.time() - t0))
p.terminate(); p.wait()
subprocess.run(["curl","-s","-u","khrip:khrip-pass","http://127.0.0.1:8123/","--data-binary","DROP TABLE IF EXISTS rv3_khrip.conc_t"])
