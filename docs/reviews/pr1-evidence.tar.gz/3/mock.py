#!/usr/bin/env python3
"""Hostile HTTP peer for db_http.kh probes. Raw sockets, one thread per connection."""
import socket
import sys
import threading
import time

PORT = int(sys.argv[1])
stats = {"conns": 0, "reqs": 0, "active": 0, "peak": 0}
lock = threading.Lock()


def read_request(conn, buf):
    while b"\r\n\r\n" not in buf:
        d = conn.recv(65536)
        if not d:
            return None, b""
        buf += d
    head, rest = buf.split(b"\r\n\r\n", 1)
    lines = head.split(b"\r\n")
    target = lines[0].split(b" ")[1].decode()
    length = 0
    for l in lines[1:]:
        k, v = l.split(b":", 1)
        if k.strip().lower() == b"content-length":
            length = int(v.strip())
    while len(rest) < length:
        d = conn.recv(65536)
        if not d:
            break
        rest += d
    return target, rest[length:]


def handle(conn):
    with lock:
        stats["conns"] += 1
    buf = b""
    try:
        while True:
            target, buf = read_request(conn, buf)
            if target is None:
                return
            path = target.split("?", 1)[0]
            with lock:
                stats["reqs"] += 1
            if path == "/stats":
                body = repr(stats).encode()
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: %d\r\n\r\n" % len(body) + body)
                continue
            if path == "/ok":
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok")
                continue
            if path == "/hold":
                with lock:
                    stats["active"] += 1
                    stats["peak"] = max(stats["peak"], stats["active"])
                time.sleep(2.0)
                with lock:
                    stats["active"] -= 1
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok")
                continue
            if path == "/stall-mid-body":
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 100\r\n\r\n" + b"x" * 50)
                time.sleep(3)
                return
            if path == "/stall-mid-chunk":
                conn.sendall(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n10\r\n12345")
                time.sleep(3)
                return
            if path == "/drip":
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 1000\r\n\r\n")
                for i in range(1000):
                    try:
                        conn.sendall(b"y")
                    except OSError:
                        return
                    time.sleep(0.01)
                return
            if path == "/eof-truncated":
                # HTTP/1.1 response without framing: body is "until close"; server dies mid-row.
                conn.sendall(b"HTTP/1.1 200 OK\r\n\r\n" + bytes([1, 5]) + b"value" + bytes([5]) + b"Int64" + (7).to_bytes(8, "little") + (8).to_bytes(8, "little"))
                conn.shutdown(socket.SHUT_WR)
                time.sleep(0.2)
                return
            if path == "/eof-http10":
                conn.sendall(b"HTTP/1.0 200 OK\r\n\r\n" + bytes([1, 5]) + b"value" + bytes([5]) + b"Int64" + (7).to_bytes(8, "little"))
                conn.shutdown(socket.SHUT_WR)
                time.sleep(0.2)
                return
            if path == "/many-tiny-chunks":
                conn.sendall(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n" + b"1\r\nx\r\n" * 65535 + b"0\r\n\r\n")
                continue
            if path == "/one-chunk":
                conn.sendall(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n" + b"%x\r\n" % 65535 + b"x" * 65535 + b"\r\n0\r\n\r\n")
                continue
            if path == "/dup-exception":
                conn.sendall(b"HTTP/1.1 200 OK\r\nX-ClickHouse-Exception-Code: 241\r\nX-ClickHouse-Exception-Code: 0\r\nContent-Length: 2\r\n\r\nok")
                continue
            if path == "/exception-header-200":
                conn.sendall(b"HTTP/1.1 200 OK\r\nX-ClickHouse-Exception-Code: 241\r\nContent-Length: 2\r\n\r\nok")
                continue
            if path == "/garbage-status":
                conn.sendall(b"HTTP/1.1 2x0 OK\r\nContent-Length: 2\r\n\r\nok")
                return
            if path == "/bare-lf":
                conn.sendall(b"HTTP/1.1 200 OK\nContent-Length: 2\n\nok")
                return
            if path == "/te-chunked-uppercase":
                conn.sendall(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: Chunked\r\n\r\n2\r\nok\r\n0\r\n\r\n")
                continue
            if path == "/te-list":
                conn.sendall(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: gzip, chunked\r\n\r\n2\r\nok\r\n0\r\n\r\n")
                continue
            if path == "/cl-plus":
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: +2\r\n\r\nok")
                continue
            if path == "/cl-list":
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2, 2\r\n\r\nok")
                continue
            if path == "/extra-after":
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nokHTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nzz")
                continue
            if path == "/late-unsolicited":
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok")
                time.sleep(0.1)
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 4\r\n\r\nevil")
                continue
            if path == "/close-after-response":
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok")
                time.sleep(0.05)
                return
            if path == "/interim-102":
                conn.sendall(b"HTTP/1.1 102 Processing\r\n\r\n" * 3 + b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok")
                continue
            if path == "/trailer-te":
                conn.sendall(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nok\r\n0\r\nTransfer-Encoding: chunked\r\n\r\n")
                continue
            if path == "/huge-chunk-hex":
                conn.sendall(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\nFFFFFFFFFFFFFFFFFFFFFFFF\r\n")
                return
            if path == "/neg-cl":
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: -1\r\n\r\n")
                return
            if path == "/304-body":
                conn.sendall(b"HTTP/1.1 204 No Content\r\nContent-Length: 0\r\n\r\n")
                continue
            if path == "/reset":
                conn.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, b"\x01\x00\x00\x00\x00\x00\x00\x00")
                conn.close()
                return
            conn.sendall(b"HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n")
    except OSError:
        pass
    finally:
        try:
            conn.close()
        except OSError:
            pass


srv = socket.socket()
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(("127.0.0.1", PORT))
srv.listen(1024)
while True:
    c, _ = srv.accept()
    threading.Thread(target=handle, args=(c,), daemon=True).start()
