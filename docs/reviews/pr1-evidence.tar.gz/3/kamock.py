import socket, sys, threading, select
PORT = int(sys.argv[1]); IDLE = float(sys.argv[2])
def handle(c):
    buf = b""
    try:
        while True:
            r, _, _ = select.select([c], [], [], IDLE)
            if not r:
                c.close(); return
            d = c.recv(65536)
            if not d: c.close(); return
            buf += d
            while b"\r\n\r\n" in buf:
                head, rest = buf.split(b"\r\n\r\n", 1)
                n = 0
                for l in head.split(b"\r\n")[1:]:
                    k, v = l.split(b":", 1)
                    if k.lower() == b"content-length": n = int(v)
                while len(rest) < n:
                    rest += c.recv(65536)
                buf = rest[n:]
                c.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nKeep-Alive: timeout=1\r\n\r\nok")
    except OSError:
        pass
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("127.0.0.1", PORT)); s.listen(64)
while True:
    c, _ = s.accept(); threading.Thread(target=handle, args=(c,), daemon=True).start()
