#!/bin/bash
# usage: run_srv.sh binary port paths...
bin=$1; port=$2; shift 2
PORT=$port THREADS=1 CLICKHOUSE_URL=http://127.0.0.1:8124 CLICKHOUSE_USER=khrip CLICKHOUSE_PASSWORD=khrip-pass $bin >/dev/null 2>&1 &
pid=$!
for i in $(seq 100); do curl -s localhost:$port/ready >/dev/null && break; sleep 0.05; done
for p in "$@"; do curl -s localhost:$port$p; echo; done
kill $pid
