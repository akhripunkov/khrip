import concurrent.futures, json, os, subprocess, sys, time, urllib.request
binary = sys.argv[1]; port = 37500
env = dict(os.environ, PORT=str(port), THREADS="1")
srv = subprocess.Popen([binary], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
base = f"http://127.0.0.1:{port}"
def get(p):
    with urllib.request.urlopen(base + p, timeout=60) as r: return json.loads(r.read())
for _ in range(200):
    try:
        get("/ready"); break
    except Exception: time.sleep(0.02)
def cpu():
    f = open(f"/proc/{srv.pid}/stat").read().split(")")[1].split()
    return (int(f[11]) + int(f[12])) / os.sysconf("SC_CLK_TCK")
# Test 1: FIFO order
order = []; t0 = time.time()
def job(i):
    time.sleep(i * 0.01)
    r = get(f"/run/{i}?s=0.2")
    order.append(i)
    return r
c0 = cpu()
with concurrent.futures.ThreadPoolExecutor(max_workers=40) as p:
    res = list(p.map(job, range(30)))
print("fifo: all ok", all(r["ok"] for r in res), "wall", round(time.time() - t0, 2), "cpu", cpu() - c0)
print("completion order", order)
# Test 2: CPU while N wait
for n in (100, 300):
    c0 = cpu(); t0 = time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=n + 1) as p:
        futs = [p.submit(get, "/run/0?s=2&timeout_ms=2500")]
        time.sleep(0.1)
        futs += [p.submit(get, f"/run/{i}?s=2&timeout_ms=2500") for i in range(1, n + 1)]
        time.sleep(2.0)
        c1 = cpu(); t1 = time.time()
        rs = [f.result() for f in futs]
    print(f"waiters={n}: cpu {c1 - c0:.2f}s in wall {t1 - t0:.2f}s; ok={sum(r['ok'] for r in rs)} timeouts={sum(not r['ok'] for r in rs)}")
srv.kill()
