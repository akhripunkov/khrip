import json

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from openai import APIStatusError, AsyncOpenAI
from pydantic import BaseModel

app = FastAPI()
client = AsyncOpenAI()


class Ask(BaseModel):
    prompt: str


@app.post("/chat")
async def chat(ask: Ask):
    if not ask.prompt:
        raise HTTPException(400, "prompt is required")
    try:
        stream = await client.chat.completions.create(
            model="gpt-4o-mini", messages=[{"role": "user", "content": ask.prompt}], stream=True)
    except APIStatusError as e:
        raise HTTPException(502, f"upstream returned {e.status_code}")

    async def events():
        async with stream:
            async for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield f"data: {json.dumps({'text': chunk.choices[0].delta.content})}\n\n"

    return StreamingResponse(events(), media_type="text/event-stream")
