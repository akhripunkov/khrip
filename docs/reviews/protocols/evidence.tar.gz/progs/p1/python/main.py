import json
import os

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

URL = "https://api.openai.com/v1/chat/completions"
app = FastAPI()
client = httpx.AsyncClient(timeout=httpx.Timeout(30, read=None))


class Ask(BaseModel):
    prompt: str


@app.post("/chat")
async def chat(ask: Ask):
    if not ask.prompt:
        raise HTTPException(400, "prompt is required")
    req = client.build_request(
        "POST", URL,
        headers={"Authorization": f"Bearer {os.environ.get('OPENAI_API_KEY', '')}"},
        json={"model": "gpt-4o-mini", "messages": [{"role": "user", "content": ask.prompt}], "stream": True},
    )
    resp = await client.send(req, stream=True)
    if resp.status_code // 100 != 2:
        await resp.aclose()
        raise HTTPException(502, f"upstream returned {resp.status_code}")

    async def events():
        try:
            async for line in resp.aiter_lines():
                if not line.startswith("data: ") or line == "data: [DONE]":
                    continue
                choices = json.loads(line[6:]).get("choices") or []
                text = choices[0].get("delta", {}).get("content") if choices else None
                if text:
                    yield f"data: {json.dumps({'text': text})}\n\n"
        finally:
            await resp.aclose()

    return StreamingResponse(events(), media_type="text/event-stream")
