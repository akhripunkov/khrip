import { Hono } from "hono";
import { streamSSE } from "hono/streaming";
import OpenAI from "openai";

const app = new Hono();
const openai = new OpenAI();

app.post("/chat", async (c) => {
  const { prompt } = await c.req.json<{ prompt?: string }>();
  if (!prompt) return c.text("prompt is required", 400);
  const stream = await openai.chat.completions
    .create({ model: "gpt-4o-mini", messages: [{ role: "user", content: prompt }], stream: true }, { signal: c.req.raw.signal })
    .catch((e) => e);
  if (stream instanceof OpenAI.APIError) return c.text(`upstream returned ${stream.status}`, 502);
  return streamSSE(c, async (s) => {
    for await (const chunk of stream) {
      const text = chunk.choices[0]?.delta?.content;
      if (text) await s.writeSSE({ data: JSON.stringify({ text }) });
    }
  });
});

export default app;
