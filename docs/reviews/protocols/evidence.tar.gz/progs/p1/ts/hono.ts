import { Hono } from "hono";
import { streamSSE } from "hono/streaming";

const app = new Hono();

app.post("/chat", async (c) => {
  const { prompt } = await c.req.json<{ prompt?: string }>();
  if (!prompt) return c.text("prompt is required", 400);
  const resp = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    signal: c.req.raw.signal,
    headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: "gpt-4o-mini", messages: [{ role: "user", content: prompt }], stream: true }),
  });
  if (!resp.ok) return c.text(`upstream returned ${resp.status}`, 502);
  return streamSSE(c, async (s) => {
    let buf = "";
    for await (const chunk of resp.body!.pipeThrough(new TextDecoderStream())) {
      const lines = (buf + chunk).split("\n");
      buf = lines.pop()!;
      for (const line of lines) {
        if (!line.startsWith("data: ") || line === "data: [DONE]") continue;
        const text = JSON.parse(line.slice(6)).choices?.[0]?.delta?.content;
        if (text) await s.writeSSE({ data: JSON.stringify({ text }) });
      }
    }
  });
});

export default app;
