package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"
)

type Ask struct {
	Prompt string `json:"prompt"`
}

type Msg struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type ChatReq struct {
	Model    string `json:"model"`
	Messages []Msg  `json:"messages"`
	Stream   bool   `json:"stream"`
}

type Chunk struct {
	Choices []struct {
		Delta struct {
			Content *string `json:"content"`
		} `json:"delta"`
	} `json:"choices"`
}

type Token struct {
	Text string `json:"text"`
}

const url = "https://api.openai.com/v1/chat/completions"

func chat(w http.ResponseWriter, r *http.Request) {
	var ask Ask
	if err := json.NewDecoder(r.Body).Decode(&ask); err != nil {
		http.Error(w, "invalid JSON body", http.StatusBadRequest)
		return
	}
	if ask.Prompt == "" {
		http.Error(w, "prompt is required", http.StatusBadRequest)
		return
	}
	body, _ := json.Marshal(ChatReq{Model: "gpt-4o-mini", Messages: []Msg{{Role: "user", Content: ask.Prompt}}, Stream: true})
	req, err := http.NewRequestWithContext(r.Context(), "POST", url, bytes.NewReader(body))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	req.Header.Set("Authorization", "Bearer "+os.Getenv("OPENAI_API_KEY"))
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		http.Error(w, "upstream unreachable", http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode/100 != 2 {
		http.Error(w, fmt.Sprintf("upstream returned %d", resp.StatusCode), http.StatusBadGateway)
		return
	}
	flusher, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "streaming unsupported", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	sc := bufio.NewScanner(resp.Body)
	sc.Buffer(make([]byte, 64*1024), 1024*1024)
	for sc.Scan() {
		line := sc.Text()
		if !strings.HasPrefix(line, "data: ") {
			continue
		}
		var c Chunk
		if json.Unmarshal([]byte(line[6:]), &c) != nil || len(c.Choices) == 0 || c.Choices[0].Delta.Content == nil {
			continue
		}
		data, _ := json.Marshal(Token{Text: *c.Choices[0].Delta.Content})
		if _, err := fmt.Fprintf(w, "data: %s\n\n", data); err != nil {
			return
		}
		flusher.Flush()
	}
}

func main() {
	http.HandleFunc("POST /chat", chat)
	log.Fatal(http.ListenAndServe(":8080", nil))
}
