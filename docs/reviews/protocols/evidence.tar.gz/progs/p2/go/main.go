package main

import (
	"encoding/json"
	"log"
	"net/http"
	"sync"
	"time"
	"unicode/utf8"

	"github.com/gorilla/websocket"
)

type Say struct {
	Text string `json:"text"`
}

type Line struct {
	User string `json:"user"`
	Text string `json:"text"`
	At   int64  `json:"at"`
}

type client struct {
	send chan Line
}

type room struct {
	history []Line
	clients map[*client]bool
}

var (
	mu       sync.Mutex
	rooms    = map[string]*room{}
	upgrader = websocket.Upgrader{}
)

func getRoom(name string) *room {
	r := rooms[name]
	if r == nil {
		r = &room{clients: map[*client]bool{}}
		rooms[name] = r
	}
	return r
}

func ws(w http.ResponseWriter, r *http.Request) {
	user := r.URL.Query().Get("user")
	if user == "" {
		http.Error(w, "user is required", http.StatusBadRequest)
		return
	}
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	c := &client{send: make(chan Line, 256)}
	mu.Lock()
	rm := getRoom(r.PathValue("room"))
	for _, l := range rm.history {
		c.send <- l
	}
	rm.clients[c] = true
	mu.Unlock()
	go writer(conn, c)
	defer func() {
		mu.Lock()
		if rm.clients[c] {
			delete(rm.clients, c)
			close(c.send)
		}
		mu.Unlock()
		conn.Close()
	}()
	conn.SetReadLimit(4096)
	conn.SetReadDeadline(time.Now().Add(60 * time.Second))
	conn.SetPongHandler(func(string) error {
		return conn.SetReadDeadline(time.Now().Add(60 * time.Second))
	})
	for {
		var m Say
		if err := conn.ReadJSON(&m); err != nil {
			return
		}
		if m.Text == "" || utf8.RuneCountInString(m.Text) > 500 {
			continue
		}
		line := Line{User: user, Text: m.Text, At: time.Now().Unix()}
		mu.Lock()
		rm.history = append(rm.history, line)
		if len(rm.history) > 100 {
			rm.history = rm.history[len(rm.history)-100:]
		}
		for other := range rm.clients {
			select {
			case other.send <- line:
			default:
				delete(rm.clients, other)
				close(other.send)
			}
		}
		mu.Unlock()
	}
}

func writer(conn *websocket.Conn, c *client) {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()
	defer conn.Close()
	for {
		select {
		case l, ok := <-c.send:
			conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if !ok {
				conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}
			if err := conn.WriteJSON(l); err != nil {
				return
			}
		case <-ticker.C:
			conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err := conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		}
	}
}

func messages(w http.ResponseWriter, r *http.Request) {
	mu.Lock()
	h := append([]Line{}, getRoom(r.PathValue("room")).history...)
	mu.Unlock()
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(h)
}

func main() {
	http.HandleFunc("GET /rooms/{room}/ws", ws)
	http.HandleFunc("GET /rooms/{room}/messages", messages)
	log.Fatal(http.ListenAndServe(":8080", nil))
}
