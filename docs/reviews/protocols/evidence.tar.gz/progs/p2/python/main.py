import time
from collections import defaultdict, deque

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, ValidationError

app = FastAPI()
history = defaultdict(lambda: deque(maxlen=100))
members = defaultdict(set)


class Say(BaseModel):
    text: str


@app.websocket("/rooms/{room}/ws")
async def ws(websocket: WebSocket, room: str, user: str = ""):
    if not user:
        await websocket.close(code=1008, reason="user is required")
        return
    await websocket.accept()
    members[room].add(websocket)
    try:
        for line in list(history[room]):
            await websocket.send_json(line)
        while True:
            try:
                say = Say.model_validate_json(await websocket.receive_text())
            except ValidationError:
                continue
            if not say.text or len(say.text) > 500:
                continue
            line = {"user": user, "text": say.text, "at": int(time.time())}
            history[room].append(line)
            for m in list(members[room]):
                try:
                    await m.send_json(line)
                except Exception:
                    members[room].discard(m)
    except WebSocketDisconnect:
        pass
    finally:
        members[room].discard(websocket)


@app.get("/rooms/{room}/messages")
async def messages(room: str):
    return list(history[room])
