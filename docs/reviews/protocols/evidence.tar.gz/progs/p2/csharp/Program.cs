using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Text.Json;
using System.Threading.Channels;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();
app.UseWebSockets(new WebSocketOptions { KeepAliveInterval = TimeSpan.FromSeconds(30) });

var rooms = new ConcurrentDictionary<string, Room>();

app.Map("/rooms/{room}/ws", async (HttpContext ctx, string room, string? user) =>
{
    if (!ctx.WebSockets.IsWebSocketRequest)
        return Results.BadRequest("websocket expected");
    if (string.IsNullOrEmpty(user))
        return Results.BadRequest("user is required");
    using var ws = await ctx.WebSockets.AcceptWebSocketAsync();
    var r = rooms.GetOrAdd(room, _ => new Room());
    var outbox = Channel.CreateBounded<Line>(256);
    lock (r)
    {
        foreach (var l in r.History)
            outbox.Writer.TryWrite(l);
        r.Clients.Add(outbox);
    }
    var writer = Task.Run(async () =>
    {
        await foreach (var l in outbox.Reader.ReadAllAsync())
            await ws.SendAsync(JsonSerializer.SerializeToUtf8Bytes(l, JsonSerializerOptions.Web), WebSocketMessageType.Text, true, default);
    });
    var buffer = new byte[4096];
    try
    {
        while (ws.State == WebSocketState.Open)
        {
            var res = await ws.ReceiveAsync(buffer, ctx.RequestAborted);
            if (res.MessageType == WebSocketMessageType.Close || !res.EndOfMessage)
                break;
            Say? say;
            try
            {
                say = JsonSerializer.Deserialize<Say>(buffer.AsSpan(0, res.Count), JsonSerializerOptions.Web);
            }
            catch (JsonException)
            {
                continue;
            }
            if (string.IsNullOrEmpty(say?.Text) || say.Text.Length > 500)
                continue;
            var line = new Line(user, say.Text, DateTimeOffset.UtcNow.ToUnixTimeSeconds());
            lock (r)
            {
                r.History.Add(line);
                if (r.History.Count > 100)
                    r.History.RemoveAt(0);
                foreach (var c in r.Clients.ToList())
                    if (!c.Writer.TryWrite(line))
                    {
                        r.Clients.Remove(c);
                        c.Writer.TryComplete();
                    }
            }
        }
    }
    catch (OperationCanceledException)
    {
    }
    finally
    {
        lock (r)
            r.Clients.Remove(outbox);
        outbox.Writer.TryComplete();
    }
    try
    {
        await writer;
        await ws.CloseAsync(WebSocketCloseStatus.NormalClosure, null, default);
    }
    catch (WebSocketException)
    {
    }
    return Results.Empty;
});

app.MapGet("/rooms/{room}/messages", (string room) =>
{
    var r = rooms.GetOrAdd(room, _ => new Room());
    lock (r)
        return r.History.ToArray();
});

app.Run();

class Room
{
    public List<Line> History { get; } = [];
    public HashSet<Channel<Line>> Clients { get; } = [];
}

record Say(string? Text);
record Line(string User, string Text, long At);
