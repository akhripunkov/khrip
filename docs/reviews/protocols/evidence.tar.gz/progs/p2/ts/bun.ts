type Line = { user: string; text: string; at: number };
const rooms = new Map<string, Line[]>();

const server = Bun.serve<{ room: string; user: string }>({
  routes: {
    "/rooms/:room/messages": (req) => Response.json(rooms.get(req.params.room) ?? []),
    "/rooms/:room/ws": (req, server) => {
      const user = new URL(req.url).searchParams.get("user");
      if (!user) return new Response("user is required", { status: 400 });
      if (server.upgrade(req, { data: { room: req.params.room, user } })) return;
      return new Response("websocket expected", { status: 400 });
    },
  },
  websocket: {
    open(ws) {
      ws.subscribe(ws.data.room);
      for (const l of rooms.get(ws.data.room) ?? []) ws.send(JSON.stringify(l));
    },
    message(ws, msg) {
      let text: unknown;
      try {
        text = JSON.parse(String(msg)).text;
      } catch {
        return;
      }
      if (typeof text !== "string" || !text || [...text].length > 500) return;
      const line = { user: ws.data.user, text, at: Math.floor(Date.now() / 1000) };
      const list = [...(rooms.get(ws.data.room) ?? []), line].slice(-100);
      rooms.set(ws.data.room, list);
      server.publish(ws.data.room, JSON.stringify(line));
    },
  },
});
