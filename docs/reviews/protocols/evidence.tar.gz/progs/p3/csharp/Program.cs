using Grpc.Core;
using Npgsql;
using Orders;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddGrpc();
builder.Services.AddGrpcReflection();
builder.Services.AddGrpcHealthChecks();
builder.Services.AddNpgsqlDataSource(builder.Configuration["DATABASE_URL"]!);
var app = builder.Build();
await using (var cmd = app.Services.GetRequiredService<NpgsqlDataSource>().CreateCommand(OrdersService.Schema))
    await cmd.ExecuteNonQueryAsync();
app.MapGrpcService<OrdersService>();
app.MapGrpcReflectionService();
app.MapGrpcHealthChecksService();
app.Run();

class OrdersService(NpgsqlDataSource db) : Orders.Orders.OrdersBase
{
    public const string Schema = """
        CREATE TABLE IF NOT EXISTS orders (id bigserial PRIMARY KEY, customer text NOT NULL,
            amount bigint NOT NULL CHECK (amount > 0), status text NOT NULL DEFAULT 'new',
            created_at timestamptz NOT NULL DEFAULT now());
        CREATE INDEX IF NOT EXISTS orders_customer ON orders (customer, id);
        """;
    const string Columns = "id, customer, amount, status, created_at";

    static Order Read(NpgsqlDataReader r) => new()
    {
        Id = r.GetInt64(0),
        Customer = r.GetString(1),
        Amount = r.GetInt64(2),
        Status = r.GetString(3),
        CreatedAt = r.GetDateTime(4).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ"),
    };

    public override async Task<Order> CreateOrder(NewOrder req, ServerCallContext ctx)
    {
        if (req.Customer == "" || req.Amount <= 0)
            throw new RpcException(new Status(StatusCode.InvalidArgument, "customer and a positive amount are required"));
        await using var cmd = db.CreateCommand($"INSERT INTO orders (customer, amount) VALUES ($1, $2) RETURNING {Columns}");
        cmd.Parameters.AddWithValue(req.Customer);
        cmd.Parameters.AddWithValue(req.Amount);
        await using var r = await cmd.ExecuteReaderAsync(ctx.CancellationToken);
        await r.ReadAsync(ctx.CancellationToken);
        return Read(r);
    }

    public override async Task<Order> GetOrder(GetOrderRequest req, ServerCallContext ctx)
    {
        await using var cmd = db.CreateCommand($"SELECT {Columns} FROM orders WHERE id = $1");
        cmd.Parameters.AddWithValue(req.Id);
        await using var r = await cmd.ExecuteReaderAsync(ctx.CancellationToken);
        if (!await r.ReadAsync(ctx.CancellationToken))
            throw new RpcException(new Status(StatusCode.NotFound, "order not found"));
        return Read(r);
    }

    public override async Task ListOrders(ListOrdersRequest req, IServerStreamWriter<Order> stream, ServerCallContext ctx)
    {
        await using var cmd = db.CreateCommand($"SELECT {Columns} FROM orders WHERE customer = $1 ORDER BY id");
        cmd.Parameters.AddWithValue(req.Customer);
        await using var r = await cmd.ExecuteReaderAsync(ctx.CancellationToken);
        while (await r.ReadAsync(ctx.CancellationToken))
            await stream.WriteAsync(Read(r));
    }
}
