package main

import (
	"context"
	"errors"
	"log"
	"net"
	"os"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/health"
	healthpb "google.golang.org/grpc/health/grpc_health_v1"
	"google.golang.org/grpc/reflection"
	"google.golang.org/grpc/status"

	pb "example.com/orders/pb"
)

const schema = `
CREATE TABLE IF NOT EXISTS orders (id bigserial PRIMARY KEY, customer text NOT NULL,
    amount bigint NOT NULL CHECK (amount > 0), status text NOT NULL DEFAULT 'new',
    created_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS orders_customer ON orders (customer, id);`

const columns = "id, customer, amount, status, created_at"

type server struct {
	pb.UnimplementedOrdersServer
	db *pgxpool.Pool
}

func scanOrder(row pgx.Row) (*pb.Order, error) {
	var o pb.Order
	var created time.Time
	if err := row.Scan(&o.Id, &o.Customer, &o.Amount, &o.Status, &created); err != nil {
		return nil, err
	}
	o.CreatedAt = created.UTC().Format(time.RFC3339)
	return &o, nil
}

func (s *server) CreateOrder(ctx context.Context, req *pb.NewOrder) (*pb.Order, error) {
	if req.Customer == "" || req.Amount <= 0 {
		return nil, status.Error(codes.InvalidArgument, "customer and a positive amount are required")
	}
	o, err := scanOrder(s.db.QueryRow(ctx, "INSERT INTO orders (customer, amount) VALUES ($1, $2) RETURNING "+columns, req.Customer, req.Amount))
	if err != nil {
		return nil, status.Error(codes.Internal, err.Error())
	}
	return o, nil
}

func (s *server) GetOrder(ctx context.Context, req *pb.GetOrderRequest) (*pb.Order, error) {
	o, err := scanOrder(s.db.QueryRow(ctx, "SELECT "+columns+" FROM orders WHERE id = $1", req.Id))
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, status.Error(codes.NotFound, "order not found")
	}
	if err != nil {
		return nil, status.Error(codes.Internal, err.Error())
	}
	return o, nil
}

func (s *server) ListOrders(req *pb.ListOrdersRequest, stream pb.Orders_ListOrdersServer) error {
	rows, err := s.db.Query(stream.Context(), "SELECT "+columns+" FROM orders WHERE customer = $1 ORDER BY id", req.Customer)
	if err != nil {
		return status.Error(codes.Internal, err.Error())
	}
	defer rows.Close()
	for rows.Next() {
		o, err := scanOrder(rows)
		if err != nil {
			return status.Error(codes.Internal, err.Error())
		}
		if err := stream.Send(o); err != nil {
			return err
		}
	}
	return rows.Err()
}

func main() {
	ctx := context.Background()
	db, err := pgxpool.New(ctx, os.Getenv("DATABASE_URL"))
	if err != nil {
		log.Fatal(err)
	}
	if _, err := db.Exec(ctx, schema); err != nil {
		log.Fatal(err)
	}
	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatal(err)
	}
	s := grpc.NewServer()
	pb.RegisterOrdersServer(s, &server{db: db})
	healthpb.RegisterHealthServer(s, health.NewServer())
	reflection.Register(s)
	log.Fatal(s.Serve(lis))
}
