import asyncio
import os

import asyncpg
import grpc
from grpc_health.v1 import health, health_pb2_grpc
from grpc_reflection.v1alpha import reflection

import orders_pb2
import orders_pb2_grpc

SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (id bigserial PRIMARY KEY, customer text NOT NULL,
    amount bigint NOT NULL CHECK (amount > 0), status text NOT NULL DEFAULT 'new',
    created_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS orders_customer ON orders (customer, id);
"""
COLUMNS = "id, customer, amount, status, created_at"


def to_order(r):
    return orders_pb2.Order(id=r["id"], customer=r["customer"], amount=r["amount"], status=r["status"],
                            created_at=r["created_at"].strftime("%Y-%m-%dT%H:%M:%SZ"))


class Orders(orders_pb2_grpc.OrdersServicer):
    def __init__(self, pool):
        self.pool = pool

    async def CreateOrder(self, request, context):
        if not request.customer or request.amount <= 0:
            await context.abort(grpc.StatusCode.INVALID_ARGUMENT, "customer and a positive amount are required")
        row = await self.pool.fetchrow(
            f"INSERT INTO orders (customer, amount) VALUES ($1, $2) RETURNING {COLUMNS}", request.customer, request.amount)
        return to_order(row)

    async def GetOrder(self, request, context):
        row = await self.pool.fetchrow(f"SELECT {COLUMNS} FROM orders WHERE id = $1", request.id)
        if row is None:
            await context.abort(grpc.StatusCode.NOT_FOUND, "order not found")
        return to_order(row)

    async def ListOrders(self, request, context):
        async with self.pool.acquire() as conn, conn.transaction():
            async for row in conn.cursor(f"SELECT {COLUMNS} FROM orders WHERE customer = $1 ORDER BY id", request.customer):
                yield to_order(row)


async def main():
    pool = await asyncpg.create_pool(os.environ["DATABASE_URL"])
    await pool.execute(SCHEMA)
    server = grpc.aio.server()
    orders_pb2_grpc.add_OrdersServicer_to_server(Orders(pool), server)
    health_pb2_grpc.add_HealthServicer_to_server(health.aio.HealthServicer(), server)
    reflection.enable_server_reflection(
        [orders_pb2.DESCRIPTOR.services_by_name["Orders"].full_name, reflection.SERVICE_NAME], server)
    server.add_insecure_port("[::]:50051")
    await server.start()
    await server.wait_for_termination()


asyncio.run(main())
