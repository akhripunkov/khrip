import * as grpc from "@grpc/grpc-js";
import * as protoLoader from "@grpc/proto-loader";
import { ReflectionService } from "@grpc/reflection";
import { HealthImplementation } from "grpc-health-check";
import pg from "pg";
import QueryStream from "pg-query-stream";

pg.types.setTypeParser(20, Number);
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
await pool.query(`
CREATE TABLE IF NOT EXISTS orders (id bigserial PRIMARY KEY, customer text NOT NULL,
    amount bigint NOT NULL CHECK (amount > 0), status text NOT NULL DEFAULT 'new',
    created_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS orders_customer ON orders (customer, id);`);

const COLUMNS = "id, customer, amount, status, created_at";
const toOrder = (r: any) => ({ ...r, created_at: r.created_at.toISOString() });
const def = protoLoader.loadSync("orders.proto", { longs: Number });
const proto = grpc.loadPackageDefinition(def) as any;

const server = new grpc.Server();
server.addService(proto.orders.Orders.service, {
  async CreateOrder(call: any, cb: grpc.sendUnaryData<any>) {
    const { customer, amount } = call.request;
    if (!customer || amount <= 0) {
      return cb({ code: grpc.status.INVALID_ARGUMENT, details: "customer and a positive amount are required" });
    }
    try {
      const { rows } = await pool.query(`INSERT INTO orders (customer, amount) VALUES ($1, $2) RETURNING ${COLUMNS}`, [customer, amount]);
      cb(null, toOrder(rows[0]));
    } catch (e) {
      cb(e as Error);
    }
  },
  async GetOrder(call: any, cb: grpc.sendUnaryData<any>) {
    try {
      const { rows } = await pool.query(`SELECT ${COLUMNS} FROM orders WHERE id = $1`, [call.request.id]);
      if (!rows.length) return cb({ code: grpc.status.NOT_FOUND, details: "order not found" });
      cb(null, toOrder(rows[0]));
    } catch (e) {
      cb(e as Error);
    }
  },
  async ListOrders(call: grpc.ServerWritableStream<any, any>) {
    const client = await pool.connect();
    try {
      const rows = client.query(new QueryStream(`SELECT ${COLUMNS} FROM orders WHERE customer = $1 ORDER BY id`, [call.request.customer]));
      for await (const r of rows) call.write(toOrder(r));
      call.end();
    } catch (e) {
      call.destroy(e as Error);
    } finally {
      client.release();
    }
  },
});
new HealthImplementation({ "": "SERVING", "orders.Orders": "SERVING" }).addToServer(server);
new ReflectionService(def).addToServer(server);
server.bindAsync("0.0.0.0:50051", grpc.ServerCredentials.createInsecure(), () => {});
