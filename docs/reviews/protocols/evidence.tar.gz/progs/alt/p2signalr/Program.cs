using System.Collections.Concurrent;
using Microsoft.AspNetCore.SignalR;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSignalR();
builder.Services.AddSingleton<History>();
var app = builder.Build();
app.MapHub<ChatHub>("/chat");
app.MapGet("/rooms/{room}/messages", (string room, History h) => h.Get(room));
app.Run();

class History
{
    readonly ConcurrentDictionary<string, List<Line>> rooms = new();

    public Line[] Get(string room)
    {
        var list = rooms.GetOrAdd(room, _ => []);
        lock (list)
            return list.ToArray();
    }

    public void Add(string room, Line line)
    {
        var list = rooms.GetOrAdd(room, _ => []);
        lock (list)
        {
            list.Add(line);
            if (list.Count > 100)
                list.RemoveAt(0);
        }
    }
}

class ChatHub(History history) : Hub
{
    public async Task<Line[]> Join(string room)
    {
        await Groups.AddToGroupAsync(Context.ConnectionId, room);
        return history.Get(room);
    }

    public async Task Send(string room, string user, string text)
    {
        if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(text) || text.Length > 500)
            return;
        var line = new Line(user, text, DateTimeOffset.UtcNow.ToUnixTimeSeconds());
        history.Add(room, line);
        await Clients.Group(room).SendAsync("line", line);
    }
}

record Line(string User, string Text, long At);
