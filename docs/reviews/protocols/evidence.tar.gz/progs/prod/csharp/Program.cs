using System.Net.ServerSentEvents;
using System.Runtime.CompilerServices;
using System.Text.Json;
using Microsoft.AspNetCore.HttpLogging;
using OpenTelemetry.Metrics;
using OpenTelemetry.Trace;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddHttpClient();
builder.Logging.AddJsonConsole();
builder.Services.AddHttpLogging(o => o.LoggingFields = HttpLoggingFields.RequestMethod | HttpLoggingFields.RequestPath | HttpLoggingFields.ResponseStatusCode | HttpLoggingFields.Duration);
builder.Services.AddOpenTelemetry().WithMetrics(m => m.AddAspNetCoreInstrumentation().AddPrometheusExporter()).WithTracing(t => t.AddAspNetCoreInstrumentation().AddHttpClientInstrumentation());
var app = builder.Build();
app.UseHttpLogging();
app.MapPrometheusScrapingEndpoint().RequireHost("*:9100");

app.MapPost("/chat", async (Ask ask, IHttpClientFactory factory, CancellationToken ct) =>
{
    if (string.IsNullOrEmpty(ask.Prompt))
        return Results.BadRequest("prompt is required");
    var req = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions")
    {
        Content = JsonContent.Create(new ChatReq("gpt-4o-mini", [new Msg("user", ask.Prompt)], true)),
    };
    req.Headers.Authorization = new("Bearer", Environment.GetEnvironmentVariable("OPENAI_API_KEY"));
    var resp = await factory.CreateClient().SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
    if (!resp.IsSuccessStatusCode)
        return Results.Problem($"upstream returned {(int)resp.StatusCode}", statusCode: 502);
    return Results.ServerSentEvents(Tokens(resp, ct));
});

app.Run();

static async IAsyncEnumerable<Token> Tokens(HttpResponseMessage resp, [EnumeratorCancellation] CancellationToken ct)
{
    using var _ = resp;
    var stream = await resp.Content.ReadAsStreamAsync(ct);
    await foreach (var item in SseParser.Create(stream).EnumerateAsync(ct))
    {
        if (item.Data == "[DONE]")
            yield break;
        var chunk = JsonSerializer.Deserialize<Chunk>(item.Data, JsonSerializerOptions.Web);
        var text = chunk?.Choices.FirstOrDefault()?.Delta.Content;
        if (text != null)
            yield return new Token(text);
    }
}

record Ask(string Prompt);
record Msg(string Role, string Content);
record ChatReq(string Model, Msg[] Messages, bool Stream);
record Delta(string? Content);
record Choice(Delta Delta);
record Chunk(Choice[] Choices);
record Token(string Text);
