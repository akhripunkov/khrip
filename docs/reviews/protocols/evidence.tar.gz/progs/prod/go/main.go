package main

import (
	"context"
	"log/slog"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"
)

type Ask struct {
	Prompt string `json:"prompt"`
}

type Msg struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type ChatReq struct {
	Model    string `json:"model"`
	Messages []Msg  `json:"messages"`
	Stream   bool   `json:"stream"`
}

type Chunk struct {
	Choices []struct {
		Delta struct {
			Content *string `json:"content"`
		} `json:"delta"`
	} `json:"choices"`
}

type Token struct {
	Text string `json:"text"`
}

const url = "https://api.openai.com/v1/chat/completions"

func chat(w http.ResponseWriter, r *http.Request) {
	var ask Ask
	if err := json.NewDecoder(r.Body).Decode(&ask); err != nil {
		http.Error(w, "invalid JSON body", http.StatusBadRequest)
		return
	}
	if ask.Prompt == "" {
		http.Error(w, "prompt is required", http.StatusBadRequest)
		return
	}
	body, _ := json.Marshal(ChatReq{Model: "gpt-4o-mini", Messages: []Msg{{Role: "user", Content: ask.Prompt}}, Stream: true})
	req, err := http.NewRequestWithContext(r.Context(), "POST", url, bytes.NewReader(body))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	req.Header.Set("Authorization", "Bearer "+os.Getenv("OPENAI_API_KEY"))
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		http.Error(w, "upstream unreachable", http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode/100 != 2 {
		http.Error(w, fmt.Sprintf("upstream returned %d", resp.StatusCode), http.StatusBadGateway)
		return
	}
	flusher, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "streaming unsupported", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	sc := bufio.NewScanner(resp.Body)
	sc.Buffer(make([]byte, 64*1024), 1024*1024)
	for sc.Scan() {
		line := sc.Text()
		if !strings.HasPrefix(line, "data: ") {
			continue
		}
		var c Chunk
		if json.Unmarshal([]byte(line[6:]), &c) != nil || len(c.Choices) == 0 || c.Choices[0].Delta.Content == nil {
			continue
		}
		data, _ := json.Marshal(Token{Text: *c.Choices[0].Delta.Content})
		if _, err := fmt.Fprintf(w, "data: %s\n\n", data); err != nil {
			return
		}
		flusher.Flush()
	}
}

var (
	requests = promauto.NewCounterVec(prometheus.CounterOpts{Name: "http_requests_total"}, []string{"method", "route", "code"})
	duration = promauto.NewHistogramVec(prometheus.HistogramOpts{Name: "http_request_duration_seconds"}, []string{"method", "route"})
)

type statusWriter struct {
	http.ResponseWriter
	code int
}

func (w *statusWriter) WriteHeader(code int) {
	w.code = code
	w.ResponseWriter.WriteHeader(code)
}

func (w *statusWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

func (w *statusWriter) Flush() {
	http.NewResponseController(w.ResponseWriter).Flush()
}

func observe(mux *http.ServeMux) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		sw := &statusWriter{ResponseWriter: w, code: http.StatusOK}
		mux.ServeHTTP(sw, r)
		_, route := mux.Handler(r)
		elapsed := time.Since(start)
		requests.WithLabelValues(r.Method, route, strconv.Itoa(sw.code)).Inc()
		duration.WithLabelValues(r.Method, route).Observe(elapsed.Seconds())
		slog.Info("request", "method", r.Method, "route", route, "status", sw.code, "ms", elapsed.Milliseconds(), "traceparent", r.Header.Get("traceparent"))
	})
}

func main() {
	slog.SetDefault(slog.New(slog.NewJSONHandler(os.Stderr, nil)))
	mux := http.NewServeMux()
	mux.HandleFunc("POST /chat", chat)
	go http.ListenAndServe(":9100", promhttp.Handler())
	srv := &http.Server{Addr: ":8080", Handler: observe(mux), ReadHeaderTimeout: 10 * time.Second, IdleTimeout: 650 * time.Second}
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGTERM, os.Interrupt)
	defer stop()
	go func() {
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatal(err)
		}
	}()
	<-ctx.Done()
	shutdown, cancel := context.WithTimeout(context.Background(), 25*time.Second)
	defer cancel()
	srv.Shutdown(shutdown)
}
