import * as grpc from "@grpc/grpc-js";
import * as protoLoader from "@grpc/proto-loader";
import { serve } from "@hono/node-server";
import { Hono } from "hono";

type User = { id: number; name: string; email: string };
const users = new Map<number, User>();
let lastId = 0;

class ApiError extends Error {
  constructor(public status: 400 | 404 | 409, message: string) {
    super(message);
  }
}
const GRPC_CODES = { 400: grpc.status.INVALID_ARGUMENT, 404: grpc.status.NOT_FOUND, 409: grpc.status.ALREADY_EXISTS };

function createUser(name: string, email: string): User {
  if (!/^[^@\s]+@[^@\s]+$/.test(email)) throw new ApiError(400, "email is invalid");
  if ([...users.values()].some((u) => u.email === email)) throw new ApiError(409, "email is taken");
  const user = { id: ++lastId, name, email };
  users.set(user.id, user);
  return user;
}

function getUser(id: number): User {
  const user = users.get(id);
  if (!user) throw new ApiError(404, "user not found");
  return user;
}

const listUsers = (limit: number) => [...users.values()].slice(0, limit || 20);

function deleteUser(id: number) {
  if (!users.delete(id)) throw new ApiError(404, "user not found");
}

const app = new Hono();
app.onError((e, c) => (e instanceof ApiError ? c.json({ detail: e.message }, e.status) : c.json({ detail: "internal error" }, 500)));
app.post("/users", async (c) => {
  const { name, email } = await c.req.json<{ name?: unknown; email?: unknown }>();
  if (typeof name !== "string" || typeof email !== "string") throw new ApiError(400, "name and email are required");
  return c.json(createUser(name, email), 201);
});
app.get("/users/:id", (c) => c.json(getUser(Number(c.req.param("id")))));
app.get("/users", (c) => c.json(listUsers(Number(c.req.query("limit") ?? 20))));
app.delete("/users/:id", (c) => {
  deleteUser(Number(c.req.param("id")));
  return c.body(null, 204);
});
serve({ fetch: app.fetch, port: 8080 });

function unary(fn: (req: any) => object) {
  return (call: any, cb: grpc.sendUnaryData<object>) => {
    try {
      cb(null, fn(call.request));
    } catch (e) {
      cb(e instanceof ApiError ? { code: GRPC_CODES[e.status], details: e.message } : (e as Error));
    }
  };
}

const proto = grpc.loadPackageDefinition(protoLoader.loadSync("users.proto", { longs: Number })) as any;
const server = new grpc.Server();
server.addService(proto.users.Users.service, {
  CreateUser: unary((r) => createUser(r.name, r.email)),
  GetUser: unary((r) => getUser(r.id)),
  ListUsers: unary((r) => ({ users: listUsers(r.limit) })),
  DeleteUser: unary((r) => {
    deleteUser(r.id);
    return {};
  }),
});
server.bindAsync("0.0.0.0:50051", grpc.ServerCredentials.createInsecure(), () => {});
