using System.Text.RegularExpressions;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Users;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.ConfigureKestrel(o =>
{
    o.ListenAnyIP(8080, l => l.Protocols = HttpProtocols.Http1);
    o.ListenAnyIP(50051, l => l.Protocols = HttpProtocols.Http2);
});
builder.Services.AddGrpc().AddJsonTranscoding();
builder.Services.AddSingleton<UserStore>();
var app = builder.Build();
app.MapGrpcService<UsersService>();
app.Run();

class UserStore
{
    public readonly object Lock = new();
    public readonly SortedDictionary<long, User> Users = [];
    public long LastId;
}

partial class UsersService(UserStore store) : Users.Users.UsersBase
{
    [GeneratedRegex(@"^[^@\s]+@[^@\s]+$")]
    private static partial Regex Email();

    public override Task<User> CreateUser(NewUser req, ServerCallContext ctx)
    {
        if (!Email().IsMatch(req.Email))
            throw new RpcException(new Status(StatusCode.InvalidArgument, "email is invalid"));
        lock (store.Lock)
        {
            if (store.Users.Values.Any(u => u.Email == req.Email))
                throw new RpcException(new Status(StatusCode.AlreadyExists, "email is taken"));
            var user = new User { Id = ++store.LastId, Name = req.Name, Email = req.Email };
            store.Users[user.Id] = user;
            return Task.FromResult(user);
        }
    }

    public override Task<User> GetUser(GetUserRequest req, ServerCallContext ctx)
    {
        lock (store.Lock)
            return store.Users.TryGetValue(req.Id, out var u)
                ? Task.FromResult(u)
                : throw new RpcException(new Status(StatusCode.NotFound, "user not found"));
    }

    public override Task<ListUsersResponse> ListUsers(ListUsersRequest req, ServerCallContext ctx)
    {
        var limit = req.Limit == 0 ? 20 : req.Limit;
        lock (store.Lock)
            return Task.FromResult(new ListUsersResponse { Users = { store.Users.Values.Take(limit) } });
    }

    public override Task<Empty> DeleteUser(DeleteUserRequest req, ServerCallContext ctx)
    {
        lock (store.Lock)
            return store.Users.Remove(req.Id)
                ? Task.FromResult(new Empty())
                : throw new RpcException(new Status(StatusCode.NotFound, "user not found"));
    }
}
