package main

import (
	"context"
	"log"
	"net"
	"net/http"
	"regexp"
	"sort"
	"sync"

	"github.com/grpc-ecosystem/grpc-gateway/v2/runtime"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/emptypb"

	pb "example.com/users/pb"
)

var emailRe = regexp.MustCompile(`^[^@\s]+@[^@\s]+$`)

type server struct {
	pb.UnimplementedUsersServer
	mu     sync.Mutex
	users  map[int64]*pb.User
	lastID int64
}

func (s *server) CreateUser(ctx context.Context, req *pb.NewUser) (*pb.User, error) {
	if !emailRe.MatchString(req.Email) {
		return nil, status.Error(codes.InvalidArgument, "email is invalid")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, u := range s.users {
		if u.Email == req.Email {
			return nil, status.Error(codes.AlreadyExists, "email is taken")
		}
	}
	s.lastID++
	u := &pb.User{Id: s.lastID, Name: req.Name, Email: req.Email}
	s.users[u.Id] = u
	return u, nil
}

func (s *server) GetUser(ctx context.Context, req *pb.GetUserRequest) (*pb.User, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[req.Id]
	if !ok {
		return nil, status.Error(codes.NotFound, "user not found")
	}
	return u, nil
}

func (s *server) ListUsers(ctx context.Context, req *pb.ListUsersRequest) (*pb.ListUsersResponse, error) {
	limit := int(req.Limit)
	if limit == 0 {
		limit = 20
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]*pb.User, 0, len(s.users))
	for _, u := range s.users {
		out = append(out, u)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Id < out[j].Id })
	if len(out) > limit {
		out = out[:limit]
	}
	return &pb.ListUsersResponse{Users: out}, nil
}

func (s *server) DeleteUser(ctx context.Context, req *pb.DeleteUserRequest) (*emptypb.Empty, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.users[req.Id]; !ok {
		return nil, status.Error(codes.NotFound, "user not found")
	}
	delete(s.users, req.Id)
	return &emptypb.Empty{}, nil
}

func main() {
	srv := &server{users: map[int64]*pb.User{}}
	g := grpc.NewServer()
	pb.RegisterUsersServer(g, srv)
	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatal(err)
	}
	go func() { log.Fatal(g.Serve(lis)) }()
	mux := runtime.NewServeMux()
	if err := pb.RegisterUsersHandlerServer(context.Background(), mux, srv); err != nil {
		log.Fatal(err)
	}
	log.Fatal(http.ListenAndServe(":8080", mux))
}
