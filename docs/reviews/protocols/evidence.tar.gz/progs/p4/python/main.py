import asyncio
import re

import grpc
import uvicorn
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from google.protobuf import empty_pb2
from pydantic import BaseModel

import users_pb2
import users_pb2_grpc

EMAIL = re.compile(r"[^@\s]+@[^@\s]+")
GRPC_CODES = {400: grpc.StatusCode.INVALID_ARGUMENT, 404: grpc.StatusCode.NOT_FOUND, 409: grpc.StatusCode.ALREADY_EXISTS}
users: dict[int, dict] = {}
last_id = 0


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        self.status, self.message = status, message


def create_user(name: str, email: str) -> dict:
    global last_id
    if not EMAIL.fullmatch(email):
        raise ApiError(400, "email is invalid")
    if any(u["email"] == email for u in users.values()):
        raise ApiError(409, "email is taken")
    last_id += 1
    users[last_id] = {"id": last_id, "name": name, "email": email}
    return users[last_id]


def get_user(id: int) -> dict:
    if id not in users:
        raise ApiError(404, "user not found")
    return users[id]


def list_users(limit: int) -> list[dict]:
    return list(users.values())[:limit or 20]


def delete_user(id: int) -> None:
    if users.pop(id, None) is None:
        raise ApiError(404, "user not found")


app = FastAPI()


class NewUser(BaseModel):
    name: str
    email: str


@app.exception_handler(ApiError)
async def api_error(request: Request, exc: ApiError):
    return JSONResponse(status_code=exc.status, content={"detail": exc.message})


@app.post("/users", status_code=201)
async def http_create(body: NewUser):
    return create_user(body.name, body.email)


@app.get("/users/{id}")
async def http_get(id: int):
    return get_user(id)


@app.get("/users")
async def http_list(limit: int = 20):
    return list_users(limit)


@app.delete("/users/{id}", status_code=204)
async def http_delete(id: int):
    delete_user(id)
    return Response(status_code=204)


class Users(users_pb2_grpc.UsersServicer):
    async def CreateUser(self, request, context):
        try:
            return users_pb2.User(**create_user(request.name, request.email))
        except ApiError as e:
            await context.abort(GRPC_CODES[e.status], e.message)

    async def GetUser(self, request, context):
        try:
            return users_pb2.User(**get_user(request.id))
        except ApiError as e:
            await context.abort(GRPC_CODES[e.status], e.message)

    async def ListUsers(self, request, context):
        return users_pb2.ListUsersResponse(users=[users_pb2.User(**u) for u in list_users(request.limit)])

    async def DeleteUser(self, request, context):
        try:
            delete_user(request.id)
            return empty_pb2.Empty()
        except ApiError as e:
            await context.abort(GRPC_CODES[e.status], e.message)


async def main():
    server = grpc.aio.server()
    users_pb2_grpc.add_UsersServicer_to_server(Users(), server)
    server.add_insecure_port("[::]:50051")
    await server.start()
    await uvicorn.Server(uvicorn.Config(app, host="0.0.0.0", port=8080)).serve()


asyncio.run(main())
