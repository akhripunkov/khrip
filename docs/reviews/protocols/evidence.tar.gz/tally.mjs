import { measure } from '/home/user/khrip/bench/tokens/count.mjs';
import { readdirSync } from 'node:fs';
const P = process.argv[2];
const langs = ['khrip', 'go', 'csharp', 'python'];
const rows = [];
for (const p of ['p1', 'p2', 'p3', 'p4']) {
  const row = { p };
  for (const l of langs) {
    const dir = `${P}/${p}/${l}`;
    const files = readdirSync(dir).filter(f => /\.(kh|go|cs|py|proto)$/.test(f));
    let o = 0, c = 0, lines = 0, detail = [];
    for (const f of files) { const m = measure(`${dir}/${f}`); o += m.o200k; c += m.claude; lines += m.lines; detail.push(`${f}:${m.o200k}/${m.claude}`); }
    row[l] = { o, c, lines, detail: detail.join(' ') };
  }
  rows.push(row);
}
console.log('| Program | Khrip | Go | C# | Python | Go/Khrip | C#/Khrip | Py/Khrip |');
console.log('|---|---:|---:|---:|---:|---:|---:|---:|');
const tot = { khrip: [0,0], go: [0,0], csharp: [0,0], python: [0,0] };
for (const r of rows) {
  for (const l of langs) { tot[l][0] += r[l].o; tot[l][1] += r[l].c; }
  const f = (l) => `${r[l].o} (${r[l].c})`;
  const ratio = (l) => `${(r[l].o / r.khrip.o).toFixed(2)} (${(r[l].c / r.khrip.c).toFixed(2)})`;
  console.log(`| ${r.p} | ${f('khrip')} | ${f('go')} | ${f('csharp')} | ${f('python')} | ${ratio('go')} | ${ratio('csharp')} | ${ratio('python')} |`);
}
const ft = (l) => `${tot[l][0]} (${tot[l][1]})`;
const rt = (l) => `${(tot[l][0]/tot.khrip[0]).toFixed(2)} (${(tot[l][1]/tot.khrip[1]).toFixed(2)})`;
console.log(`| total | ${ft('khrip')} | ${ft('go')} | ${ft('csharp')} | ${ft('python')} | ${rt('go')} | ${rt('csharp')} | ${rt('python')} |`);
console.log();
for (const r of rows) for (const l of langs) console.log(r.p, l, r[l].lines, 'lines;', r[l].detail);
