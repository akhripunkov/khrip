// Mechanical estimate of D5 on the eval solutions:
// (1) drop the type name of a struct literal whose target type is known;
// (2) inline a named struct type that is used exactly once, as a field or list element type of another type.
import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { measure } from '/home/user/khrip/bench/tokens/count.mjs';
const SRC = '/home/user/khrip/eval/solutions', OUT = process.argv[2];
let tb = 0, ta = 0, cb = 0, ca = 0;
const rows = [];
for (const task of readdirSync(SRC).sort()) {
  const f = `${SRC}/${task}/khrip/main.kh`;
  let s = readFileSync(f, 'utf8');
  let lits = 0, inl = 0;
  const T = '[A-Z][A-Za-z0-9]*';
  const rep = (re, to) => { s = s.replace(re, (...m) => { lits++; return typeof to === 'function' ? to(...m) : to.replace('$1', m[1] ?? ''); }); };
  rep(new RegExp(`\\breturn( [0-9]{3})? ${T} \\{`, 'g'), (m, st) => `return${st ?? ''} {`);
  rep(new RegExp(`(send|push|publish)\\((.*?)${T} \\{`, 'g'), (m, fn, pre) => `${fn}(${pre}{`);
  rep(new RegExp(`^(\\s*(?!let |var )[a-z_][\\w.\\[\\]"{}]*) = ${T} \\{`, 'gm'), (m, lhs) => `${lhs} = {`);
  rep(new RegExp(`([a-z_]\\w*): ${T} \\{`, 'g'), (m, fld) => `${fld}: {`);
  // (2) inline single-use types declared on one line: type X { ... }
  for (const m of [...s.matchAll(/^type ([A-Z]\w*) (\{[^\n]*\})\n/gm)]) {
    const name = m[1], body = m[2];
    if (body.includes('...')) continue;
    const uses = [...s.matchAll(new RegExp(`\\b${name}\\b`, 'g'))].length - 1;
    const asField = [...s.matchAll(new RegExp(`(: |\\[)${name}\\b(?!\\s*\\{)`, 'g'))];
    const inTypes = asField.filter(u => { const ls = s.lastIndexOf('\ntype ', u.index); const le = s.indexOf('\n}', ls); const lineEnd = s.indexOf('\n', ls + 1); return ls >= 0 && (u.index < lineEnd || (s.slice(ls, lineEnd).endsWith('{') && u.index < le)); });
    if (uses === 1 && (inTypes.length === 1 || (process.env.ANY && asField.length + [...s.matchAll(new RegExp(`-> ${name}\\b`, "g"))].length === 1))) {
      s = s.replace(m[0], '');
      s = s.replace(new RegExp(`(: |\\[|-> )${name}\\b`), `$1${body}`);
      inl++;
    }
  }
  writeFileSync(`${OUT}/${task}.kh`, s);
  const b = measure(f), a = measure(`${OUT}/${task}.kh`);
  tb += b.o200k; ta += a.o200k; cb += b.claude; ca += a.claude;
  rows.push(`| ${task} | ${b.o200k} (${b.claude}) | ${a.o200k} (${a.claude}) | ${a.o200k - b.o200k} | ${lits} | ${inl} |`);
}
console.log('| Task | Today | With D5 | Change | Literals | Inlined types |\n|---|---:|---:|---:|---:|---:|');
console.log(rows.join('\n'));
console.log(`| total | ${tb} (${cb}) | ${ta} (${ca}) | ${ta - tb} (${ca - cb}) | | |`);
