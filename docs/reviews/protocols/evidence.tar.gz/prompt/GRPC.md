# gRPC in Khrip

```khrip
service shop.v1.Orders                      // optional: shop.kh alone gives shop.Shop

rpc CreateOrder POST "/orders" (body: NewOrder) -> 201 Order | 400 str {
    return 201 sql "INSERT INTO orders {body} RETURNING *"
}
rpc GetOrder GET "/orders/{id}" (id: int) -> Order | 404 {
    return sql "SELECT * FROM orders WHERE id = {id}"
}
rpc ListOrders (customer: str) -> stream Order {
    for o: Order in sql "SELECT * FROM orders WHERE customer = {customer} ORDER BY id" {
        send(o)
    }
}
rpc Import (rows: stream NewOrder) -> Summary { ... }    // client stream
rpc Chat (msgs: stream Say) -> stream Line { ... }        // both ways
```

- `rpc Name` serves gRPC, gRPC-Web and Connect (JSON or protobuf) at
  `/shop.v1.Orders/Name`. With a method and a path it is also a REST route.
- The request message is the parameters (`GetOrderRequest { id }`); a single
  struct parameter is the message itself, so adding a second parameter later
  breaks clients. A result that is not a struct is wrapped:
  `ListUsersResponse { items }`.
- Types: `int` int64, `float` double, `str` string, `[T]` repeated, `map[K, V]`
  map, structs are messages, variants are `oneof`. A missing field that is not
  `T?` and has no default is INVALID_ARGUMENT, as in JSON; a missing list is
  empty.
- Statuses become codes: 400 INVALID_ARGUMENT, 401 UNAUTHENTICATED, 403
  PERMISSION_DENIED, 404 NOT_FOUND, 409 ALREADY_EXISTS, 412 FAILED_PRECONDITION
  (for version conflicts), 429 RESOURCE_EXHAUSTED, 503 UNAVAILABLE, a panic
  INTERNAL; the text is the message.
- `header(name)` reads metadata, `set_header` sends it. The client's deadline
  bounds `fetch` and `sql`; a cancelled call ends at its next wait. Health and
  reflection are built in.
- khc writes `shop.proto` beside `shop.kh` with stable field numbers: commit it
  (`khc -o` needs it). A changed field type is an error; to rename a field,
  rename it in the .proto too.
- `khc proto quotes.proto` writes `quotes.kh`: the types and rpcs to call,
  `rpc GetQuote (sym: str) -> Quote at env("QUOTES_URL")`. `let q =
  GetQuote("ACME")`: NOT_FOUND ends the request with 404 (into `Quote?`: none),
  UNAVAILABLE 503, a timeout 504, any other code 502.
- Tests: `call GetOrder(1)` returns a `Response`; `open ListOrders("ann")` reads
  a stream.
