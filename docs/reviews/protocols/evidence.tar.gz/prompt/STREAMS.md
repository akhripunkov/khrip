## Streams, WebSocket, topics

```khrip
topic chat: Line

route POST "/ask" (body: Ask) -> stream Token {
    for data in fetch POST LLM_URL body {    // SSE data or lines; not 2xx: 502
        let c: Chunk? = from_json(data)
        if c != none {
            send(Token { text: c.text })
        }
    }
}

route GET "/rooms/{id}" (id: str, user: str, msgs: stream Say) -> stream Line {
    subscribe(chat[id], rooms[id] ?? [])     // history first, then live values
    for m in msgs {                          // WebSocket messages, one at a time
        publish(chat[id], Line { user, text: m.text, at: now() })
    }
}
```

- `-> stream T` sends each `send(v)` as SSE, NDJSON or gRPC, as the client
  asks; before the first `send` the route may `return 404`.
- `msgs: stream T` is a WebSocket with `GET`, an NDJSON body with `POST`; read
  it with `for m in msgs` directly in the route body. Each WebSocket message is
  a request for the `sql` rules; in a `POST` loop a write needs `tx { }`.
- `subscribe(t, history)` sends `history`, or only what a reconnecting client
  missed, then every later `publish(t, v)` in this process until the client
  leaves, even after the route returns.
- A client that leaves ends the route at its next `send` or wait. In a WebSocket
  loop read `store` inside the loop: a value read before it stays as it was.

`let s = open GET "/rooms/1?user=ann"` opens a stream in a test: `s.send(v)`,
`let m: Line? = s.next()` (none at the end).

`yield`, `Flush()` → `send(v)`; `onmessage` → `for m in msgs`; a map of
connections → `topic`.
