// prompt + program per task, weighted: w = price of a prompt token / price of an output token
const W = [0.02, 0.2];
const core = 3000, streams = 451, sql = 896, grpc = 655, today = 4165, rule = 25;
const prot = [
  // name, khrip, khripD5, prompt, competitors {name: program}
  ['P1', 243, 195, core + streams, { 'Python+SDK': 229, 'Hono+SDK': 239, Python: 351, Hono: 326, 'C#': 405, Go: 694 }],
  ['P2', 209, 205, core + streams, { Python: 301, Bun: 327, 'C# SignalR': 331, 'C#': 684, Go: 834 }],
  ['P3', 229, 223, core + sql + grpc, { Python: 700, TS: 772, 'C#': 794, Go: 966 }],
  ['P4', 254, 254, core + grpc, { Python: 951, TS: 936, 'C#': 798, Go: 991 }],
];
for (const w of W) {
  console.log(`\nw = ${w}`);
  console.log('| Program | Khrip | Khrip with D5 | Best other | Margin (D5) |');
  for (const [n, k, k5, p, comp] of prot) {
    const [bn, bv] = Object.entries(comp).sort((a, b) => a[1] - b[1])[0];
    const kk = Math.round(k + p * w), kd = Math.round(k5 + p * w), b = Math.round(bv + rule * w);
    console.log(`| ${n} | ${kk} | ${kd} | ${b} (${bn}) | ${b - kd} |`);
  }
}
const ev = [['shortener',388,382,513,466,949],['bank',488,478,563,621,972],['notes',602,598,872,892,1184],['ratelimit',410,401,396,462,629],['catalog',757,756,824,829,1345],['inventory',708,696,765,866,1215],['polls',663,649,710,783,1220],['bookings',573,573,711,778,990],['ledger',1020,1011,1460,1679,2542,1],['shop',2029,1984,2433,3160,4286,1],['tracker',1246,1242,1926,2589,3094,1]];
for (const w of W) {
  console.log(`\nexisting tasks, w = ${w}: today's prompt ${today}; planned core ${core} (+ SQL ${sql} for database tasks)`);
  let wt = 0, wp = 0, wd = 0;
  for (const [n, k, k5, py, cs, go, db] of ev) {
    const best = Math.min(py, cs, go) + rule * w;
    const t = k + today * w, pl = k + (core + (db ? sql : 0)) * w, d = k5 + (core + (db ? sql : 0)) * w;
    wt += t < best; wp += pl < best; wd += d < best;
    console.log(`| ${n} | ${Math.round(t)} | ${Math.round(pl)} | ${Math.round(d)} | ${Math.round(best)} |`);
  }
  console.log(`wins: today ${wt}/11, planned core ${wp}/11, planned core + D5 ${wd}/11`);
}
