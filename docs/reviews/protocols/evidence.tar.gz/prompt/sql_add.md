- `for o: Order in sql "..."` reads rows one at a time; inside it only `send`
  waits (no other `sql` or `fetch`).
