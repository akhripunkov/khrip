- Timeouts, body limits, SIGTERM draining, logs, metrics, TLS and CORS come
  from environment variables (SERVER.md), not code.

`fetch ... timeout 5 s` sets its deadline (default 30 s).
