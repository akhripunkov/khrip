## PostgreSQL

```khrip
migration 1 `
CREATE TABLE accounts (id bigserial PRIMARY KEY, owner text NOT NULL,
    balance bigint NOT NULL DEFAULT 0, created_at timestamptz NOT NULL DEFAULT now());
`
route GET "/accounts/{id}" (id: int) -> Account | 404 {
    return sql "SELECT * FROM accounts WHERE id = {id}"      // no row: 404
}
route POST "/accounts" (body: NewAccount) -> 201 Account {
    return 201 sql "INSERT INTO accounts {body} RETURNING *"  // fields → columns
}
let a: Account? = sql "SELECT * FROM accounts WHERE owner = {name} LIMIT 1"
let all: [Account] = sql `SELECT * FROM accounts
    WHERE ({owner} IS NULL OR owner = {owner}) AND id IN ({ids}) ORDER BY id`
let n: int = sql "SELECT count(*) FROM accounts"
let changed = sql "DELETE FROM accounts WHERE balance = 0"   // rows changed
sql "UPDATE accounts SET {patch} WHERE id = {id}"            // only fields sent
tx {
    let from: Account = sql "SELECT * FROM accounts WHERE id = {a}"
    if from.balance < amount {
        return 409 "insufficient funds"                      // rolls back
    }
    sql "UPDATE accounts SET balance = balance - {amount} WHERE id = {a}"
}
```

- `sql "..."` (or `` `...` `` for several lines) runs one statement; `{expr}` is
  sent as a parameter, never as SQL text (`none` is NULL, so compare an optional
  as `({x} IS NULL OR col = {x})`); `IN ({list})` takes a list; `name ILIKE
  '%{q}%'` matches q literally; `ORDER BY {o}` takes `o` made of string literals
  (`const`, `if`, `match`).
- The expected type picks the result: `T` one row, none → 404 (the route lists
  `| 404`, or answer yourself: `let r: T = sql "..." else { return 401 }`); `T?`
  one row or none, more is an error (add `LIMIT 1`); `[T]` all rows; no type:
  rows changed. `T` is a struct (columns by name) or one column's type.
  timestamptz/date → `str` (as `time_iso`) or `int`; jsonb → any type; a
  nullable column needs `T?`.
- `INSERT INTO t {v}` puts fields into columns of the same name (`none` → the
  column default), `{[v]}` inserts a list in one statement; `SET {patch}` sets
  only the fields the request sent. Duplicate allowed: `let r: T? = sql "INSERT
  ... ON CONFLICT DO NOTHING RETURNING *"`.
- `migration N` runs once, in order, when the server starts (`DATABASE_URL`);
  never edit one that ran: add the next number. At start the server checks every
  `sql` against the database and refuses to run with precise errors.
- A failed statement ends the request: duplicate or CHECK 409, missing foreign
  key 404, row still referenced 409, NOT NULL or a bad value 400, database down
  or busy 503.
- Outside `tx` each statement commits on its own, so in a route a write after
  another statement (or in a loop) is an error: put them in `tx { }`. `tx` is
  SERIALIZABLE and re-runs on a conflict, so inside it no `fetch`, `sleep`,
  MongoDB or ClickHouse network operations,
  `call`, store or outer-variable changes; a status from 400, `fail` or a panic
  rolls it back. `let t = tx { ...; value }` commits and gives the value.

