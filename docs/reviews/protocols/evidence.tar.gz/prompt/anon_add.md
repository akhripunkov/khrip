- `{ text: t }` (names without quotes) is a struct literal whose type comes from
  where it goes: `return`, `send`, a typed parameter, field or list; with no
  such place, its type is its fields. `{"k": v}` stays a map. A struct type can
  be written in place: `-> { token: str }`, `choices: [{ delta: { text: str? } }]`.
