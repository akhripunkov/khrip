import asyncio, sys
N = int(sys.argv[1]); pid = int(sys.argv[2])
def rss():
    for l in open(f"/proc/{pid}/status"):
        if l.startswith("VmRSS"): return int(l.split()[1])
async def main():
    base = rss(); conns = []
    for _ in range(N):
        r, w = await asyncio.open_connection("127.0.0.1", 18124)
        conns.append((r, w))
    opened = rss()
    for r, w in conns:
        w.write(b"GET /sleep?ms=0 HTTP/1.1\r\nHost: x\r\n\r\n")
    for r, w in conns:
        await r.readuntil(b"ok")
    used = rss()
    print(f"N={N} base={base} KB open(no request)={opened} KB after one request each={used} KB per idle keep-alive conn={(used-base)/N:.1f} KB")
    for r, w in conns: w.close()
asyncio.run(main())
