using System.Net.WebSockets;

var builder = WebApplication.CreateBuilder(args);
builder.Logging.ClearProviders();
var app = builder.Build();
app.UseWebSockets();
app.Map("/echo", async (HttpContext ctx) =>
{
    using var ws = await ctx.WebSockets.AcceptWebSocketAsync();
    var buf = new byte[4096];
    while (true)
    {
        var r = await ws.ReceiveAsync(buf, default);
        if (r.MessageType == WebSocketMessageType.Close) break;
        await ws.SendAsync(buf.AsMemory(0, r.Count), r.MessageType, r.EndOfMessage, default);
    }
});
app.Run("http://127.0.0.1:18128");
