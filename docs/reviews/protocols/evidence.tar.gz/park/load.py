import asyncio, sys, os, time
N = int(sys.argv[1]); path = sys.argv[2]; pid = int(sys.argv[3])
def rss():
    for l in open(f"/proc/{pid}/status"):
        if l.startswith("VmRSS"): return int(l.split()[1])
async def one():
    r, w = await asyncio.open_connection("127.0.0.1", 18123)
    w.write(f"GET {path} HTTP/1.1\r\nHost: x\r\n\r\n".encode()); await w.drain()
    await r.read(1000); w.close()
async def main():
    base = rss()
    tasks = [asyncio.create_task(one()) for _ in range(N)]
    await asyncio.sleep(1.5)
    peak = rss()
    await asyncio.gather(*tasks)
    after = rss()
    print(f"N={N} path={path} rss base={base} KB parked={peak} KB after={after} KB per-parked={(peak-base)/N:.1f} KB")
asyncio.run(main())
