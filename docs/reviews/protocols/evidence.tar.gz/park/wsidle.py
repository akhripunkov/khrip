import asyncio, sys, websockets
N = int(sys.argv[1]); url = sys.argv[2]; pid = int(sys.argv[3]); send = sys.argv[4] if len(sys.argv) > 4 else None
def rss():
    for l in open(f"/proc/{pid}/status"):
        if l.startswith("VmRSS"): return int(l.split()[1])
async def main():
    base = rss(); conns = []
    for i in range(N):
        ws = await websockets.connect(url, ping_interval=None, max_queue=None)
        conns.append(ws)
    if send:
        await conns[0].send(send)
        await asyncio.sleep(2)
    await asyncio.sleep(1)
    used = rss()
    print(f"{url}: N={N} base={base} KB with N idle={used} KB per idle WS={(used-base)/N:.1f} KB")
    for ws in conns: await ws.close()
asyncio.run(main())
