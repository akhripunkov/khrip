import { WebSocketServer } from 'ws';
const wss = new WebSocketServer({ port: 18127 });
wss.on('connection', (ws) => { ws.on('message', (m) => ws.send(m)); });
