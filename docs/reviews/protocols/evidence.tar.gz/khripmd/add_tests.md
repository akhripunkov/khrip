`let s = open GET "/rooms/1?user=ann"` starts a stream or WebSocket in a test:
`s.send(v)`; `let m: Line? = s.next()` is the next value, none at the end or
when nothing more would arrive.
