## gRPC

`rpc GetOrder GET "/orders/{id}" (id: int) -> Order | 404 { ... }` is a route
that also serves gRPC, gRPC-Web and Connect; without the method and path it has
no REST route. khc writes `app.proto` beside `app.kh` with stable field numbers:
commit it. See [GRPC.md](GRPC.md).
