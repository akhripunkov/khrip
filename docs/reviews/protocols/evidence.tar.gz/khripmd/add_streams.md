## Streams, WebSocket, topics

```khrip
topic chat: Line

route POST "/ask" (body: Ask) -> stream Token {
    for data in fetch POST LLM_URL body {
        let c: Chunk? = from_json(data)
        if c != none {
            send(Token { text: c.text })
        }
    }
}

route GET "/rooms/{id}" (id: str, user: str, msgs: stream Say) -> stream Line {
    subscribe(chat[id])
    for m in msgs {
        publish(chat[id], Line { user, text: m.text, at: now() })
    }
}
```

- `-> stream T` sends values with `send(v)` until the route returns, in the
  format the client asks for: Server-Sent Events, NDJSON, a JSON array or gRPC.
  Before the first `send` the route may `return 404`; after it, `fail` or a
  panic ends the stream with an error.
- A `stream T` parameter is read with `for m in msgs`: with `GET` the route is a
  WebSocket (text messages, JSON for `T`); with `POST` the body is NDJSON, a JSON
  array or, for `stream str`, lines.
- `topic name: T` broadcasts across connections and threads (`name[key]`: one
  channel). `subscribe(t)` forwards every later `publish(t, v)` to this client,
  even after the route returns, until it leaves; `unsubscribe(t)` stops. It is
  true when it replayed what a reconnecting SSE client missed (`Last-Event-ID`):
  send history from `store` only `if !subscribe(t)`, and nothing is lost or
  repeated. A client 1 MB behind is dropped.
- `for x in fetch ...` reads the response as it arrives (SSE `data` or lines); a
  status other than 2xx ends the route with 502.
- A client that leaves ends the route at its next `send` or wait. Inside a loop
  over a stream, variables from outside it act like `store`: assigning copies.
