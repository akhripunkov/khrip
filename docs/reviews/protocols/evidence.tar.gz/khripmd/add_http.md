- Built in: slow-client timeouts, bodies and messages up to `KHRIP_MAX_BODY` (4
  MB, chunked too), draining on SIGTERM, JSON request logs with W3C trace ids
  (`KHRIP_LOG=requests`; `fetch` passes them on), Prometheus metrics and health
  checks (`METRICS_PORT`), HTTPS and HTTP/2 (`TLS_CERT`, `TLS_KEY`), CORS
  (`KHRIP_CORS`).
