`yield`, `Flush()` → `send(v)`; `ReadMessage`, `onmessage` → `for m in msgs`;
a map of connections → `topic`;
