`fetch ... timeout 5 s` sets its deadline (default 30 s, never past the
request's own).
