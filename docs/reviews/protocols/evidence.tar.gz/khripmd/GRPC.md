# gRPC in Khrip

```khrip
service shop.v1.Orders                      // optional: shop.kh alone gives shop.Shop

rpc CreateOrder POST "/orders" (body: NewOrder) -> 201 Order | 400 str {
    return 201 sql "INSERT INTO orders {body} RETURNING *"
}
rpc GetOrder GET "/orders/{id}" (id: int) -> Order | 404 {
    return sql "SELECT * FROM orders WHERE id = {id}"
}
rpc ListOrders (customer: str) -> stream Order {
    for o: Order in sql "SELECT * FROM orders WHERE customer = {customer} ORDER BY id" {
        send(o)
    }
}
rpc Import (rows: stream NewOrder) -> Summary { ... }    // client stream
rpc Chat (msgs: stream Say) -> stream Line { ... }        // both ways
```

- `rpc Name` serves gRPC (HTTP/2 with TLS, or h2c), gRPC-Web and Connect (JSON
  or protobuf, HTTP/1.1 or 2) at `/shop.v1.Orders/Name`. With a method and a
  path it is also a REST route with the same code.
- The request message is the parameters (`GetOrderRequest { id }`); a single
  struct parameter is the message itself. A result that is not a struct (`[T]`,
  `str`, `int`) is wrapped: `ListUsersResponse { items }`.
- Types: `int` int64, `float` double, `bool`, `str` string, `[T]` repeated,
  `map[K, V]` map, `T?` optional, structs are messages, enums are enums (number
  0 is `UNSPECIFIED` and reads as an error), variants are `oneof`. A field
  missing on the wire reads as zero, as in protobuf; a default other than zero
  applies.
- Statuses become codes: 400 INVALID_ARGUMENT, 401 UNAUTHENTICATED, 403
  PERMISSION_DENIED, 404 NOT_FOUND, 409 ALREADY_EXISTS, 412
  FAILED_PRECONDITION, 429 RESOURCE_EXHAUSTED, 503 UNAVAILABLE, 504
  DEADLINE_EXCEEDED, a panic INTERNAL; the status text is the message. Connect
  clients get the matching HTTP status.
- `header(name)` reads metadata and `set_header` sends it. `grpc-timeout` is the
  call's deadline, also for its `fetch` and `sql`; a cancelled call ends at its
  next wait. The health service (`grpc.health.v1`, NOT_SERVING while draining)
  and reflection are built in.
- khc writes `shop.proto` beside `shop.kh`: a new field takes the next number, a
  removed one is reserved, and a changed type is an error. Commit the file and
  never edit numbers; to rename a field without breaking clients, rename it in
  the .proto too.
- `khc proto quotes.proto` writes `quotes.kh`: the types, and rpcs without a
  body to call: `rpc GetQuote (sym: str) -> Quote at env("QUOTES_URL")`, then
  `let q = GetQuote("ACME")` (NOT_FOUND → 404, UNAVAILABLE → 503, as `sql`).
- Tests: `call GetOrder(1)` returns a `Response` (the code as its HTTP status, the
  message as JSON); `open ListOrders("ann")` reads a stream.
