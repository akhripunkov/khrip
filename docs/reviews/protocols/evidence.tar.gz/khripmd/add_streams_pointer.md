## Streams, WebSocket, topics

`route POST "/ask" (body: Ask) -> stream Token { ... send(t) ... }` streams values
(SSE, NDJSON, a JSON array, gRPC); a `stream T` parameter is a WebSocket (`GET`)
or a streamed body (`POST`); `topic` broadcasts. See [STREAMS.md](STREAMS.md).
